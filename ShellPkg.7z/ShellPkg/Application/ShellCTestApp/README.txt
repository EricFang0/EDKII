TestArgv.nsh is a very simple shell script to test how the interpreter parses
the parameters. It uses ShellCTestApp.efi to dump the parameters passed from the
intepreter.

TestArgv.log is the desired output created using "TestArgv.nsh > TestArgv.log".