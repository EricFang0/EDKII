/*
	OEM defined by EricFang 	--	2018-05-22
*/
#include "OemDefineShellCmdLib.h"
#include "EricTestBase.h"


EFI_STATUS ShellDelay_ms (UINT32 Delay)
{
	gBS->Stall(Delay*1000);
	return EFI_SUCCESS;
}

EFI_STATUS ShellDelay_s (UINT32 Delay)
{
	while(Delay--)
	{
		//ShellPrintEx(0, gST->ConOut->Mode->CursorRow, L"Wait for %d seconds", Delay);
		ShellPrintHiiEx(0, gST->ConOut->Mode->CursorRow, NULL, STRING_TOKEN (STR_SHELL_DELAY), gShellOemDefineHiiHandle, Delay);
		gBS->Stall(1000000);
	}
	ShellPrintEx(0, gST->ConOut->Mode->CursorRow, L"                                                                           \r\n");	
	return EFI_SUCCESS;
}

void EFIAPI 
TimeShow(      IN EFI_EVENT Event,
			   IN VOID *Context
			   )
{
	EFI_TIME 	ET;
	UINTN 		x,y;

	//Get current cursor position
	x = gST->ConOut->Mode->CursorColumn;
	y = gST->ConOut->Mode->CursorRow;

	//Output current time
	gRT->GetTime(&ET,NULL);
	//Move cursor to Right-Up
//	gST->ConOut->SetCursorPosition(gST->ConOut,5,2);

	ShellPrintHiiEx(88, 0, NULL, STRING_TOKEN (STR_SHELL_DATE_SHOW), gShellOemDefineHiiHandle, ET.Year,ET.Month,ET.Day);
	ShellPrintHiiEx(88, 1, NULL, STRING_TOKEN (STR_SHELL_TIME_SHOW), gShellOemDefineHiiHandle, ET.Hour,ET.Minute,ET.Second);
	
//	Print(L"%d:%d:%d--%d:%d:%d",ET.Year,ET.Month,ET.Day,ET.Hour,ET.Minute,ET.Second);

	gST->ConOut->SetCursorPosition(gST->ConOut,x,y);
}

void TimeShowOnScreen(UINT8 Enable)
{
	EFI_STATUS				Status;
	EFI_EVENT				TimerOne = NULL;
	STATIC CONST UINTN 		SecondsToNanoSeconds = 50000000;

	if(Enable!=0)
	{
		Status = gBS->CreateEvent(
							EVT_NOTIFY_SIGNAL|EVT_TIMER,
							TPL_CALLBACK,
							TimeShow,
							NULL,
							&TimerOne
							);
		if(EFI_ERROR(Status))
		{
			Print(L"Creat Event Error\r\n");
		}

		Status = gBS->SetTimer(
							TimerOne,
							TimerPeriodic,
							MultU64x32(SecondsToNanoSeconds, 1)
								);
		if(EFI_ERROR(Status))
		{
			Print(L"Set Timer Error\r\n");
		}
	}else{

		gBS->CloseEvent(TimerOne);
	}

	
}



SHELL_STATUS
EFIAPI
ShellCommandRunEDID(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{ 
  SHELL_STATUS        ShellStatus = SHELL_SUCCESS;;       
  EFI_STATUS		  Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;

   //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);
	
  //
  // parse the command line
  //
  Status = ShellCommandLineParse (EmptyParamList, &Package, &ProblemParam, TRUE);
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"stall", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
  } else{
		GetEDID();
  }

 return ShellStatus; 
}


SHELL_STATUS
EFIAPI
ShellCommandRunSPD(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus = SHELL_SUCCESS;
  EFI_STATUS		  Status;
   LIST_ENTRY          *Package;
   CHAR16              *ProblemParam;

   //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);
	
  //
  // parse the command line
  //
  Status = ShellCommandLineParse (EmptyParamList, &Package, &ProblemParam, TRUE);
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"stall", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
  } else{
		PrintMemorySPDData();
  }
  return ShellStatus; 
}


SHELL_STATUS
EFIAPI
ShellCommandRunUSB(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus = SHELL_SUCCESS;;       
  EFI_STATUS		  Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;

   //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);
	
  //
  // parse the command line
  //
  Status = ShellCommandLineParse (EmptyParamList, &Package, &ProblemParam, TRUE);
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"stall", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
  } else{
  		if (ShellCommandLineGetRawValue(Package, 1) != NULL) {
      		ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"OemVar");  
      		ShellStatus = SHELL_INVALID_PARAMETER;
      	}
      	else
			GetSystemUSBDeviceInfo();
			//GetAllVariableInSystem();
  }  
 
  return ShellStatus; 
}

SHELL_STATUS
EFIAPI
ShellCommandRunOemVariablePrint(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus;

  ShellStatus         = SHELL_SUCCESS;

  PrintOemVariable();
 
  return ShellStatus; 
}

SHELL_STATUS
EFIAPI
ShellCommandRunSaveVbt(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus;

  ShellStatus         = SHELL_SUCCESS;

  GetGopProtocolInstance();
 
  return ShellStatus; 
}



STATIC CONST SHELL_PARAM_ITEM OemHandleParamList[] = {
  {L"-d",   TypeFlag},
  {L"-all", TypeFlag},
  {NULL, TypeMax}
  };

SHELL_STATUS
EFIAPI
ShellCommandRunHandle(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus = SHELL_SUCCESS;;       
  EFI_STATUS		  Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;
  CONST CHAR16		  *Command2;

  //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);

  //
  // parse the command line
  //
  Status = ShellCommandLineParse (OemHandleParamList, &Package, &ProblemParam, TRUE);
  
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"Handle", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }

    return ShellStatus;
  } 

  if (ShellCommandLineGetRawValue(Package, 2) != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"Handle");  
	  ShellStatus = SHELL_INVALID_PARAMETER;
	  
	  return ShellStatus;
   }
   
  if((ShellCommandLineGetFlag(Package,L"-all"))&&(ShellCommandLineGetRawValue(Package, 1) == NULL))
  {	
      HandlePrint(L"-all",L"NULL");

      return ShellStatus;
   }

   if((ShellCommandLineGetFlag(Package,L"-d"))&&(ShellCommandLineGetRawValue(Package, 1) == NULL))
  {	
      HandlePrint(L"-d",L"NULL");

      return ShellStatus;
   }

  if ((ShellCommandLineGetFlag(Package,L"-d"))&&(ShellCommandLineGetRawValue(Package, 1) != NULL)) {
  	  Command2 = ShellCommandLineGetRawValue(Package, 1);	
      HandlePrint(L"-d",Command2);

      return ShellStatus;
   } 

	HandlePrint(L"NULL",L"NULL");

	ShellCommandLineFreeVarList (Package);
 
  return ShellStatus; 
}

SHELL_STATUS
EFIAPI
ShellCommandRunDebugMemPrint(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus;

  ShellStatus         = SHELL_SUCCESS;

  DebugMemDump();
 
  return ShellStatus; 
}

SHELL_STATUS
EFIAPI
ShellCommandRunCodec(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus;

  ShellStatus         = SHELL_SUCCESS;

  CheckCodec();
 
  return ShellStatus; 
}

SHELL_STATUS
EFIAPI
ShellCommandRunMemInfo(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  SHELL_STATUS        ShellStatus;

  ShellStatus         = SHELL_SUCCESS;

  GetMemInfo();
 
  return ShellStatus; 
}

STATIC CONST SHELL_PARAM_ITEM OemVarParamList[] = {
  {L"-g", TypeFlag},
  {L"-s", TypeFlag},
  {L"-d", TypeFlag},
  {L"-a", TypeFlag},
  {NULL, TypeMax}
  };



SHELL_STATUS
EFIAPI
ShellCommandRunOemVar (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS          Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;
  SHELL_STATUS        ShellStatus = SHELL_SUCCESS;
  CONST CHAR16		  *Command1;
  CONST CHAR16		  *Command2;
  UINT64			  CmdValue=0x11;

  //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);

  //
  // parse the command line
  //
  
  Status = ShellCommandLineParse (OemVarParamList, &Package, &ProblemParam, TRUE);		//check parameter valid
  if (EFI_ERROR(Status)) {	
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"OemVar", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
    return ShellStatus;
  }
 

  if (ShellCommandLineGetRawValue(Package, 1) == NULL) {			//check parameter too few
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"OemVar");  
      ShellStatus = SHELL_INVALID_PARAMETER;
      return ShellStatus;
    }

    Command1 = ShellCommandLineGetRawValue(Package, 1);				//Get Parameter1

    if(StrStr(Command1,L"d")!=NULL)			//Display Variable
	{
		if (ShellCommandLineGetRawValue(Package, 2) != NULL) {			//check paremeter too many
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"OemVar");  
	      ShellStatus = SHELL_INVALID_PARAMETER;
	      return ShellStatus;
	    }
		
		PrintOemVariable();
	    
		return ShellStatus;
	}

	if(StrStr(Command1,L"a")!=NULL)			// Variable CurrentCount SelfAdd
	{
		if (ShellCommandLineGetRawValue(Package, 2) != NULL) {			//check paremeter too many
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"OemVar");  
	      ShellStatus = SHELL_INVALID_PARAMETER;
	      return ShellStatus;
	    }
		
		UINT16 Count = OemVariableCountSelfAdd();
		ShellPrintHiiEx(0, gST->ConOut->Mode->CursorRow, NULL, STRING_TOKEN (STR_SHELL_CURRENTCOUNT), gShellOemDefineHiiHandle, Count);
		gST->ConOut->Mode->CursorRow +=1;
		ShellPrintEx(0, gST->ConOut->Mode->CursorRow, L" ");
	    
		return ShellStatus;
	}

	if (ShellCommandLineGetRawValue(Package, 2) == NULL) {			//check parameter too few
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"OemVar");  
      ShellStatus = SHELL_INVALID_PARAMETER;
      return ShellStatus;
    }

	Command2 = ShellCommandLineGetRawValue(Package, 2);

	if(StrStr(Command1,L"g")!=NULL)			//Get Variable
	{	
		if (ShellCommandLineGetRawValue(Package, 3) != NULL) {			//check paremeter too many
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"OemVar");  
	      ShellStatus = SHELL_INVALID_PARAMETER;
	      return ShellStatus;
	    }
	    
	    Status = OemVarParamHandleGet(Command2);
	    if(EFI_ERROR(Status))
	    {
        	ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PARAM_INV), gShellOemDefineHiiHandle, L"OemVar", ShellCommandLineGetRawValue(Package, 2));  
        	ShellStatus = SHELL_INVALID_PARAMETER;
	    }
		
		return ShellStatus;
	}

	if (ShellCommandLineGetRawValue(Package, 3) == NULL) {			//check parameter too few
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"OemVar");  
      ShellStatus = SHELL_INVALID_PARAMETER;
      return ShellStatus;
    }
	Status = InternalShellStrHexToUint64(ShellCommandLineGetRawValue(Package, 3), &CmdValue, FALSE);


	if(StrStr(Command1,L"s")!=NULL)			//Set Variable
	{	
		if (ShellCommandLineGetRawValue(Package, 4) != NULL) {			//check paremeter too many
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"OemVar");  
	      ShellStatus = SHELL_INVALID_PARAMETER;
	      return ShellStatus;
	    }

	    if (ShellCommandLineGetRawValue(Package, 2) == NULL) {			//check parameter too few
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"OemVar");  
	      ShellStatus = SHELL_INVALID_PARAMETER;
	      return ShellStatus;
	    }

	    Status = OemVarParamHandleSet(Command2,(UINT32)CmdValue);

	    if(EFI_ERROR(Status))
	    {
        	ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PARAM_INV), gShellOemDefineHiiHandle, L"OemVar", ShellCommandLineGetRawValue(Package, 2));  
        	ShellStatus = SHELL_INVALID_PARAMETER;
	    }

		return ShellStatus;
	}
      
    ShellCommandLineFreeVarList (Package);
 
  return (ShellStatus);
}


STATIC CONST SHELL_PARAM_ITEM OemResetParamList[] = {
  {L"-SKL", TypeFlag},
  {L"-KBL", TypeFlag},
  {L"-KBL_R", TypeFlag},
  {L"-CFL", TypeFlag},
  {L"-ICL", TypeFlag},
  {NULL, TypeMax}
  };

SHELL_STATUS
EFIAPI
ShellCommandRunOemReset (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
	EFI_STATUS 			Status;
	SHELL_STATUS        ShellStatus = SHELL_SUCCESS;
	LIST_ENTRY          *Package;
	CHAR16              *ProblemParam;
	CONST CHAR16		*Command;
  //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);

  //
  // parse the command line
  //
  Status = ShellCommandLineParse (OemResetParamList, &Package, &ProblemParam, TRUE);		//check parameter valid
  if (EFI_ERROR(Status)) {	
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"gReset", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
    return ShellStatus;
  }

  if (ShellCommandLineGetRawValue(Package, 1) == NULL) {			//check parameter too few
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"gReset");  
      ShellStatus = SHELL_INVALID_PARAMETER;
      return ShellStatus;
    }

  if (ShellCommandLineGetRawValue(Package, 2) != NULL) {			//check paremeter too many
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"gReset");  
	      ShellStatus = SHELL_INVALID_PARAMETER;
	      return ShellStatus;
	    }  
  Command = ShellCommandLineGetRawValue(Package, 1);			

  Status = OemSystem_gReset(Command);

  if(EFI_ERROR(Status))
  {
	ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PARAM_INV), gShellOemDefineHiiHandle, L"gReset", ShellCommandLineGetRawValue(Package, 1));  
    ShellStatus = SHELL_INVALID_PARAMETER;
  }
  
  return ShellStatus;
}

SHELL_STATUS
EFIAPI
ShellCommandRunOemStall (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS          Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;
  SHELL_STATUS        ShellStatus;
  UINT64              Intermediate;

  ShellStatus         = SHELL_SUCCESS;

  //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);

  //
  // parse the command line
  //
  Status = ShellCommandLineParse (EmptyParamList, &Package, &ProblemParam, TRUE);
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"stall", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
  } else {
    if (ShellCommandLineGetRawValue(Package, 2) != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"stall");  
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else if (ShellCommandLineGetRawValue(Package, 1) == NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"stall");  
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      Status = ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 1), &Intermediate, FALSE, FALSE);
      if (EFI_ERROR(Status) || ((UINT64)(UINTN)(Intermediate)) != Intermediate) {
        ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PARAM_INV), gShellOemDefineHiiHandle, L"stall", ShellCommandLineGetRawValue(Package, 1));  
        ShellStatus = SHELL_INVALID_PARAMETER;
      } else {
        ShellDelay_s((UINT32)Intermediate);
        if (EFI_ERROR(Status)) {
          ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_STALL_FAILED), gShellOemDefineHiiHandle, L"stall");  
          ShellStatus = SHELL_DEVICE_ERROR;
        }
      }
    }
    ShellCommandLineFreeVarList (Package);
  }
  return (ShellStatus);
}

SHELL_STATUS
EFIAPI
ShellCommandRunClock (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS          Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;
  SHELL_STATUS        ShellStatus;
  UINT64              Intermediate;

  ShellStatus         = SHELL_SUCCESS;

  //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);

  //
  // parse the command line
  //
  Status = ShellCommandLineParse (EmptyParamList, &Package, &ProblemParam, TRUE);
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"stall", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
  } else {
    if (ShellCommandLineGetRawValue(Package, 2) != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"stall");  
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else if (ShellCommandLineGetRawValue(Package, 1) == NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"stall");  
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      Status = ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 1), &Intermediate, FALSE, FALSE);
      if (EFI_ERROR(Status) || ((UINT64)(UINTN)(Intermediate)) != Intermediate) {
        ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PARAM_INV), gShellOemDefineHiiHandle, L"stall", ShellCommandLineGetRawValue(Package, 1));  
        ShellStatus = SHELL_INVALID_PARAMETER;
      } else {
        TimeShowOnScreen((UINT8)Intermediate);
        if (EFI_ERROR(Status)) {
          ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_STALL_FAILED), gShellOemDefineHiiHandle, L"stall");  
          ShellStatus = SHELL_DEVICE_ERROR;
        }
      }
    }
    ShellCommandLineFreeVarList (Package);
  }
  return (ShellStatus);
}

SHELL_STATUS
EFIAPI
ShellCommandRunIoHandle (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS          Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;
  SHELL_STATUS        ShellStatus;
  CONST CHAR16		  *Cmd;
  UINT64			  Port;
  UINT64			  Index;
  UINT64			  Data;

  ShellStatus         = SHELL_SUCCESS;

  //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);

  //
  // parse the command line
  //
  Status = ShellCommandLineParse (EmptyParamList, &Package, &ProblemParam, TRUE);
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"Io", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
    return ShellStatus;
  } 

    if (ShellCommandLineGetRawValue(Package, 5) != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"Io");  
      ShellStatus = SHELL_INVALID_PARAMETER;

      return ShellStatus;
    }

    if (ShellCommandLineGetRawValue(Package,3) == NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"Io");  
      ShellStatus = SHELL_INVALID_PARAMETER;

      return ShellStatus;
    }

	Cmd = ShellCommandLineGetRawValue(Package,1);

	if(StrStr(Cmd,L"R")!=NULL)
	{
		if (ShellCommandLineGetRawValue(Package, 4) != NULL) {
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"Io");  
	      ShellStatus = SHELL_INVALID_PARAMETER;

	      return ShellStatus;
	    }

	    Status = ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 2), &Port, FALSE, FALSE);
	    Status|= ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 3), &Index, FALSE, FALSE);

	    if(Status!=EFI_SUCCESS)
	    {
	    	Io_Handle(L"E",0,0,0);
			ShellStatus = SHELL_INVALID_PARAMETER;
	      	return ShellStatus;
	    }

	    Io_Handle(L"R",Port,(UINT8)Index,0);

	    ShellCommandLineFreeVarList (Package);
	    return ShellStatus;

	}

	if(StrStr(Cmd,L"W")!=NULL)
	{
		if (ShellCommandLineGetRawValue(Package, 4) == NULL) {
	      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"Io");  
	      ShellStatus = SHELL_INVALID_PARAMETER;

	      return ShellStatus;
	    }

	    Status = ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 2), &Port, FALSE, FALSE);
	    Status|= ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 3), &Index, FALSE, FALSE);
	    Status|= ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 4), &Data, FALSE, FALSE);

	    if(Status!=EFI_SUCCESS)
	    {
	    	Io_Handle(L"E",0,0,0);
			ShellStatus = SHELL_INVALID_PARAMETER;
	      	return ShellStatus;
	    }

	    Io_Handle(L"W",Port,(UINT8)Index,(UINT8)Data);

	    ShellCommandLineFreeVarList (Package);
	    return ShellStatus;

	}

	Io_Handle(L"E",0,0,0);
    
    ShellCommandLineFreeVarList (Package);
 
  return (ShellStatus);
}

SHELL_STATUS
EFIAPI
ShellCommandRunBootOption (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS          Status;
  LIST_ENTRY          *Package;
  CHAR16              *ProblemParam;
  SHELL_STATUS        ShellStatus;
  CONST CHAR16		  *Cmd;
  CHAR16		  	  *BootCmd;
  UINT64			  Data;

  	
  ShellStatus         = SHELL_SUCCESS;

  //
  // initialize the shell lib (we must be in non-auto-init...)
  //
  Status = ShellInitialize();
  ASSERT_EFI_ERROR(Status);

  Status = CommandInit();
  ASSERT_EFI_ERROR(Status);

  //
  // parse the command line
  //
  Status = ShellCommandLineParse (EmptyParamList, &Package, &ProblemParam, TRUE);
  if (EFI_ERROR(Status)) {
    if (Status == EFI_VOLUME_CORRUPTED && ProblemParam != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_PROBLEM), gShellOemDefineHiiHandle, L"BootOption", ProblemParam);  
      FreePool(ProblemParam);
      ShellStatus = SHELL_INVALID_PARAMETER;
    } else {
      ASSERT(FALSE);
    }
    return ShellStatus;
  } 

    if (ShellCommandLineGetRawValue(Package, 3) != NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_MANY), gShellOemDefineHiiHandle, L"Io");  
      ShellStatus = SHELL_INVALID_PARAMETER;

      return ShellStatus;
    }

    if (ShellCommandLineGetRawValue(Package,1) == NULL) {
      DisplayAllBootOption();	//Display All Boot Option

      return ShellStatus;
    }

    if (ShellCommandLineGetRawValue(Package, 2) == NULL) {
      ShellPrintHiiEx(-1, -1, NULL, STRING_TOKEN (STR_GEN_TOO_FEW), gShellOemDefineHiiHandle, L"Io");  
      ShellStatus = SHELL_INVALID_PARAMETER;

      return ShellStatus;
    }

	Cmd = ShellCommandLineGetRawValue(Package,1);
	Status = ShellConvertStringToUint64(ShellCommandLineGetRawValue(Package, 2), &Data, FALSE, FALSE);

	BootCmd = (CHAR16*)Cmd;
	ChangeBootOptionAttributes(BootCmd,(UINT32)Data);
    
    ShellCommandLineFreeVarList (Package);
 
  return (ShellStatus);
}