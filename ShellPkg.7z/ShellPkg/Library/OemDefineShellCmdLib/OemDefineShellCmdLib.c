/** @file
  Main file for NULL named library for level 1 shell command functions.

  (C) Copyright 2013 Hewlett-Packard Development Company, L.P.<BR>
  Copyright (c) 2009 - 2011, Intel Corporation. All rights reserved.<BR>
  This program and the accompanying materials
  are licensed and made available under the terms and conditions of the BSD License
  which accompanies this distribution.  The full text of the license may be found at
  http://opensource.org/licenses/bsd-license.php

  THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
  WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.

**/

#include "OemDefineShellCmdLib.h"

STATIC CONST CHAR16 mFileName[] = L"ShellCommands";
EFI_HANDLE gShellOemDefineHiiHandle = NULL;

/**
  Return the help text filename.  Only used if no HII information found.

  @retval the filename.
**/
CONST CHAR16*
EFIAPI
ShellCommandGetManFileNameOemDefine (
  VOID
  )
{
  return (mFileName);
}

/**
  Constructor for the Shell Level 1 Commands library.

  Install the handlers for level 1 UEFI Shell 2.0 commands.

  @param ImageHandle    the image handle of the process
  @param SystemTable    the EFI System Table pointer

  @retval EFI_SUCCESS        the shell command handlers were installed sucessfully
  @retval EFI_UNSUPPORTED    the shell level required was not found.
**/
EFI_STATUS
EFIAPI
OemDefineShellCmdLibConstructor (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  //
  // if shell level is less than 2 do nothing
  //
  if (PcdGet8(PcdShellSupportLevel) < 1) {
    return (EFI_SUCCESS);
  }

  gShellOemDefineHiiHandle = HiiAddPackages (&gShellOemDefineHiiGuid, gImageHandle, OemDefineShellCmdLibStrings, NULL);
  if (gShellOemDefineHiiHandle == NULL) {
    return (EFI_DEVICE_ERROR);
  }

  //
  // install our shell command handlers that are always installed
  //
  ShellCommandRegisterCommandName(L"OemStall",ShellCommandRunOemStall, ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_OEM)));	
  ShellCommandRegisterCommandName(L"EDID",   ShellCommandRunEDID    , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_EDID)));
  ShellCommandRegisterCommandName(L"SPD",    ShellCommandRunSPD     , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_SPD)));
  ShellCommandRegisterCommandName(L"USB",    ShellCommandRunUSB     , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_USB)));
  ShellCommandRegisterCommandName(L"OemVar", ShellCommandRunOemVar  , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_OEMVAR_PRINT)));
  ShellCommandRegisterCommandName(L"Codec",	ShellCommandRunCodec 	, ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_CODEC)));
  ShellCommandRegisterCommandName(L"gReset",ShellCommandRunOemReset , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_GRESET)));
  ShellCommandRegisterCommandName(L"MemInfo",ShellCommandRunMemInfo , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_MEMINFO)));
  ShellCommandRegisterCommandName(L"DebugMem",ShellCommandRunDebugMemPrint , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_DEBUGMEM)));	
  ShellCommandRegisterCommandName(L"SaveVbt",ShellCommandRunSaveVbt , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_SAVE_VBT)));
  ShellCommandRegisterCommandName(L"Handle",ShellCommandRunHandle , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_HANDLE)));
  ShellCommandRegisterCommandName(L"Io",ShellCommandRunIoHandle , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_IO)));	
  ShellCommandRegisterCommandName(L"Clock",ShellCommandRunClock , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_CLOCK)));	
  ShellCommandRegisterCommandName(L"BootOption",ShellCommandRunBootOption , ShellCommandGetManFileNameOemDefine, 1, L"", FALSE, gShellOemDefineHiiHandle, (EFI_STRING_ID)(PcdGet8(PcdShellSupportLevel) < 3 ? 0 : STRING_TOKEN(STR_GET_HELP_BOOT_OPTION)));	
  	
  return (EFI_SUCCESS);
  	
  return (EFI_SUCCESS);
}

/**
  Destructor for the library.  free any resources.

  @param ImageHandle            The image handle of the process.
  @param SystemTable            The EFI System Table pointer.
**/
EFI_STATUS
EFIAPI
OemDefineShellCmdLibDestructor (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  if (gShellOemDefineHiiHandle != NULL) {
    HiiRemovePackages(gShellOemDefineHiiHandle);
  }
  return (EFI_SUCCESS);
}



