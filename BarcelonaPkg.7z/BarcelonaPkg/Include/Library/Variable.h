#ifndef _Variable_H_
#define _Variable_H_

#define OEM_VARIABLE_GUID \
  { 0x9987d643, 0xeba4, 0x4bb5, 0xa1, 0xe5, 0x3f, 0x3e, 0x36, 0xb2, 0xd, 0x99}

typedef struct
{
	UINT16 ResetCount;		//
	UINT16 CurrentResetCount;
	UINT8  ResetFlag;			//Bit0: 0:Reset Finish,1:Reseting; [1:2]: 0:Warm,1:Cold,2:gReset;  Bit3: 
	UINT16 Year;
	UINT8  Month;
	UINT8  Day;
	UINT32 OemDebugBufferAddr;
	UINT32 OemDebugBufferSize;
}OemVariableDef;

extern EFI_STATUS GetOemVariable(OUT OemVariableDef	*OemVariable);

extern EFI_STATUS EFIAPI NewOemVariable();

extern EFI_STATUS EFIAPI SetOemVariable(IN       OemVariableDef	*OemVariable);

extern EFI_STATUS EFIAPI PrintOemVariable();

EFI_STATUS OemVarParamHandleGet(CONST CHAR16* Command2);

EFI_STATUS OemVarParamHandleSet(CONST CHAR16* Command2,UINT32 Value);

UINT16 OemVariableCountSelfAdd();	

#endif