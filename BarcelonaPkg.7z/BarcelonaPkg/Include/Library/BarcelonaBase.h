#ifndef _ERIC_TEST_BASE_H
#define _ERIC_TEST_BASE_H

#include <Uefi.h>
#include <Library/PcdLib.h>
#include <Library/UefiLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/IoLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiRuntimeLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library\PciCf8Lib.h>
#include <Protocol\Shell.h>
#include <Library/PrintLib.h>

//#include <Library/ShellLib.h>
//extern EFI_SHELL_PROTOCOL     *gEfiShellProtocol;
//extern EFI_SHELL_ENVIRONMENT2 *mEfiShellEnvironment2;

#define PCIeMMIOBaseAddress         0xE0000000
#define ICL_PCIeMMIOBaseAddress     0xC0000000

#define  SetBit(mask,bit)         mask|=(1<<bit)
#define  ClearBit(mask,bit)       mask&=~(1<<bit)

#define X64_0_NT32_1    0
#define X64_1_NT32_0    !X64_0_NT32_1

#pragma pack(1)

typedef struct{
    UINT8   Byte0;
    UINT8   Byte1;
    UINT8   Byte2;
    UINT8   Byte3;
}UINT8_Type;

typedef struct{
    UINT16  Byte01;
    UINT16  Byte23;
}UINT16_Type;

typedef union{
    
    UINT8_Type  d8;
    UINT16_Type d16;
    UINT32      d32;
}UINT_32_16_8;

#pragma pack()

typedef struct{
    UINT16   VID;
    UINT32   VendorAddress;
    UINT16   VendorLength;
    //CHAR16*  Vendor;  
}USB_VendorInfo;

typedef enum {
  gTop_Left,            //0
  gTop_Center,          //1
  gTop_Right,           //2
  gCenter_Left,         //3
  gCenter,              //4
  gCenter_Right,        //5
  gBottom_Left,         //6
  gBottom_Center,       //7
  gBottom_Right,        //8
  gUser_Define,         //9
  gDisplay_Screen_BMP_Info
} OEM_GRAPHICS_SHOW_POSITION_MODE;

extern EFI_BOOT_SERVICES        *gBS;
extern EFI_SYSTEM_TABLE         *gST;
extern EFI_RUNTIME_SERVICES     *gRT;
extern EFI_HANDLE               gImageHandle;
EFI_STATUS EricGetSystemTime(void);

extern EFI_STATUS EFIAPI APPInMemTest();
extern EFI_STATUS EFIAPI CheckSMBIOS (void);
extern void HotKeyNotifyFunction();

extern EFI_STATUS EFIAPI GetFileSystemMap();
extern EFI_STATUS EFIAPI OpenCurDirectory(OUT  EFI_FILE_PROTOCOL **EfiDirectory);

extern EFI_STATUS EFIAPI SMBIOSCheck_BeforeFlashBIOS();
extern EFI_STATUS EFIAPI EnumPciDevices ();

extern EFI_STATUS GetParameter(
        IN EFI_HANDLE                            ImageHandle,
        OUT UINTN*                               Argc,
        OUT CHAR16***                            Argv
        );

UINT8 CHAR16Str2UINT8(CHAR16 *InStr,UINTN StrOffset);
UINT16 CHAR16Str2UINT16(CHAR16 *InStr,UINTN StrOffset);
UINT32 CHAR16Str2UINT32(CHAR16 *InStr,UINTN StrOffset);
EFI_STATUS UINT32ToHexCHAR16Var(IN UINT32 Dat, IN UINT8 OutLength, OUT CHAR16 *Str);
UINTN ShellAsciiPrint(
        IN CHAR8         Str,
        IN CONST CHAR8  *Format,
        ...
  );
UINTN ShellPrint(
        IN CHAR16         Str,
        IN CONST CHAR16  *Format,
        ...
  );


EFI_STATUS SSIDCheck(CHAR16 *FileName);

extern EFI_STATUS
EFIAPI
PrintPCIConfigureReg (  
    IN EFI_HANDLE        ImageHandle
);

extern EFI_STATUS EFIAPI PrintSmbusData ( IN EFI_HANDLE  ImageHandle);

extern EFI_STATUS EFIAPI PrintMemorySPDData ();

extern EFI_STATUS EFIAPI PrintVariable(IN EFI_HANDLE ImageHandle);

extern EFI_STATUS EFIAPI SetVariable();

extern EFI_STATUS PrintAllSystemVariableName001();

extern EFI_STATUS EFIAPI PictureShow (IN EFI_HANDLE ImageHandle);

EFI_STATUS EFIAPI OEMLoadImage(IN EFI_HANDLE         ImageHandle);

EFI_STATUS EFIAPI GetSystemUSBDeviceInfo();

EFI_STATUS OEMReset(IN EFI_HANDLE        ImageHandle );

EFI_STATUS EFIAPI
OpenFileInCurrentDirectory(IN CONST CHAR16 *SearchFileName,OUT EFI_FILE_PROTOCOL** SearchFileDirectory,OUT EFI_FILE_INFO **SearchFileInfo);
EFI_STATUS SearchFileByName(IN EFI_FILE_PROTOCOL* Directory, IN CONST CHAR16 *SearchFileName, OUT EFI_FILE_PROTOCOL** SearchFileDirectory, OUT EFI_FILE_INFO **SearchFileInfo);

EFI_STATUS EFIAPI CheckHDAStatus();
extern EFI_STATUS OemDelay_ms (UINT32 Delay);
extern EFI_STATUS OemDelay_s (UINT32 Delay);

EFI_STATUS CheckCodec();
EFI_STATUS ME_Reset();

extern EFI_STATUS GetEDID();

EFI_STATUS 
EFIAPI
EnumerSMBUS_Device();

void TimeShowOnScreen(UINT8 Enable);

EFI_STATUS OemSystem_gReset(CONST CHAR16* Platform);

EFI_STATUS GetMemInfo();

EFI_STATUS DebugMemDump();

EFI_STATUS GetFirmwareInfo();

EFI_STATUS ColdReset (void);        
EFI_STATUS WarmReset (void);
EFI_STATUS Delay10s (void);

extern EFI_STATUS GetEDID();

extern VOID OemReadMem (
  IN  UINT64        Address,
  IN  UINT32         Size,
  IN  VOID          *Buffer
  );

extern CHAR16 * OemAscii2Unicode (
  OUT CHAR16         *UnicodeStr,
  IN  CHAR8          *AsciiStr
  );

EFI_STATUS
HandlePrint(IN CONST CHAR16 *Cmd1,IN CONST CHAR16 *Cmd2);

EFI_STATUS
EFIAPI
ShellDefaultBootLogoShow(IN UINT8 *FileData,
                                    IN UINTN FileDataLength        
                                    );
EFI_STATUS
EFIAPI
ShellBootLogoShow(IN CHAR16            *BmpFileName);

EFI_STATUS GetGopProtocolInstance();

UINT8 HEX2DEC(CHAR16 x);
UINT8 HEX2DEC2(char x);

CHAR16 *
OemAscii2Unicode1 (
  OUT CHAR16         *UnicodeStr,
  IN  CHAR8          *AsciiStr,
  OUT UINT16         *Strlen
  );

EFI_STATUS GetDataFromExtFile(IN EFI_HANDLE         ImageHandle);

EFI_STATUS  GetAllVariableInSystem();

EFI_STATUS  Io_Handle(CHAR16 *Para1,UINT64 Port,UINT8 Index,UINT8 Data);

EFI_STATUS ChangeBootOptionAttributes(IN CHAR16 *BootName, IN UINT32 BootAttribute);

void DisplayAllBootOption();

void WindowsBootOptionEnable();

EFI_STATUS GetSystemInfo();

VOID PrintAllTypeInfo();

EFI_STATUS GetGraphicOutMode();
EFI_STATUS SetGraphicOutModeResolution(UINT32            Horizontal, UINT32 Vertical);
EFI_STATUS SetGraphicOutMode(UINT32          Mode);
EFI_STATUS GetGraphicResolutionByMode(IN UINT32 Mode,OUT UINT32 *Horizontal, OUT UINT32 *Vertical);

EFI_STATUS myTestEventSingal();

EFI_STATUS  FindVariableInSystem(IN CHAR16 *VarSearched, OUT EFI_GUID *Guid);
EFI_STATUS
SetVariableOffsetValue(
    IN CHAR16       *VarName,
    IN UINTN        Offset,
    IN UINTN        Value,
    IN UINT8        ValueType   //bit length: 8,16,32,64
);
EFI_STATUS
PrintVariableInfo(IN CHAR16 *VarName);

EFI_STATUS SaveIoMuxReg2Bin();
VOID ShowAllSCUItem();


#endif

