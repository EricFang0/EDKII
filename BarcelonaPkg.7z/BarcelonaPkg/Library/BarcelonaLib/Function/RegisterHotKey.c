#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>

#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>


extern EFI_BOOT_SERVICES         *gBS;
extern EFI_SYSTEM_TABLE      	 *gST;
extern EFI_RUNTIME_SERVICES      *gRT;
extern EFI_HANDLE         gImageHandle;



EFI_STATUS EFIAPI
HotKeyNotifyFunctionTest(IN EFI_KEY_DATA *KeyData)
{
	Print(L"This is the test of HotKey notify!\n");
	return EFI_SUCCESS;
}


void HotKeyNotifyFunction()
{
	EFI_STATUS						  Status;
	EFI_SIMPLE_TEXT_INPUT_EX_PROTOCOL *SimpleEx;
	EFI_KEY_DATA					  KeyData;
	EFI_HANDLE						  CtrlCNotifyHandle = NULL;


	Status = gBS->OpenProtocol(
		gST->ConsoleInHandle,
		&gEfiSimpleTextInputExProtocolGuid,
		(VOID**)&SimpleEx,
		gImageHandle,
		NULL,
		EFI_OPEN_PROTOCOL_GET_PROTOCOL);

	if(EFI_ERROR(Status))
	{
		Print(L"Open Protocol fail\n");
	}

	KeyData.KeyState.KeyToggleState = 0;
	KeyData.Key.ScanCode = 0;
	KeyData.KeyState.KeyShiftState = EFI_SHIFT_STATE_VALID|EFI_LEFT_CONTROL_PRESSED;
	KeyData.Key.UnicodeChar = L's';

	Status = SimpleEx->RegisterKeyNotify(
						SimpleEx,
						&KeyData,
						HotKeyNotifyFunctionTest,
						&CtrlCNotifyHandle
						);

	//Status = SimpleEx->UnregisterKeyNotify(SimpleEx,CtrlCNotifyHandle);
}

