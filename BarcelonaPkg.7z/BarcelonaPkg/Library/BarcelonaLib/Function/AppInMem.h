#ifndef _APPINMEM_H
#define _APPINMEM_H

EFI_STATUS EFIAPI APPInMemTest();


#endif

