#ifndef _CHECKSMBIOS_H
#define _CHECKSMBIOS_H

extern EFI_STATUS EFIAPI CheckSMBIOS (void);

#endif