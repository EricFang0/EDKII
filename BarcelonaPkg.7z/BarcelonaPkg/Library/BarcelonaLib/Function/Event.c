#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>

#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>
#include <Protocol/EfiShell.h>
#include <Library/ShellLib.h>

#include <SimpleFileSystem.h>
#include <Protocol/BlockIo.h>
#include <Library/DevicePathLib.h>
#include <Library/HandleParsingLib.h>
#include <Library/SortLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/BaseMemoryLib.h>
#include <LoadedImage.h>

extern EFI_BOOT_SERVICES         *gBS;
extern EFI_SYSTEM_TABLE      	 *gST;
extern EFI_RUNTIME_SERVICES      *gRT;

extern EFI_HANDLE         		 gImageHandle;
extern EFI_SHELL_ENVIRONMENT2 	 *mEfiShellEnvironment2;
STATIC CONST UINTN 				 SecondsToNanoSeconds = 500000;


