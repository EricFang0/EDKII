#include <Uefi.h>
#include <Library/PcdLib.h>
#include <Library/UefiLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/IoLib.h>
#include <Library/ShellLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiRuntimeLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/MemoryAllocationLib.h>
#include <sstd.h>

#include <EricTestBase.h>
#include "FirmwareManagement.h"



EFI_STATUS GetFirmwareInfo()
{
	EFI_STATUS							Status;
	EFI_FIRMWARE_MANAGEMENT_PROTOCOL	*FirmwareManagementProtocol;
	EFI_HANDLE							Handle;
	EFI_FIRMWARE_IMAGE_DESCRIPTOR		*ImageInfo;
	UINTN								ImageInfoSize;
	UINT32								DescriptorVersion;
	UINT8                           	DescriptorCount;
    UINTN                           	DescriptorSize;
    UINT32                          	PackageVersion;
    CHAR16                          	*PackageVersionName;

	Status = gBS->HandleProtocol(Handle,
						&gEfiFirmwareManagementProtocolGuid,
						&FirmwareManagementProtocol);
	if(EFI_ERROR(Status))
	{
		Print(L"Get Firmware Image Info fail\r\n");
		return Status;
	}

	Status = FirmwareManagementProtocol->GetImageInfo(
											FirmwareManagementProtocol,
											&ImageInfoSize,
											ImageInfo,
											&DescriptorVersion,
											&DescriptorCount,
											&DescriptorSize,
											&PackageVersion,
											&PackageVersionName
											);
	if(Status == EFI_BUFFER_TOO_SMALL)
	{
		gBS->AllocatePool(EfiRuntimeServicesData,ImageInfoSize,&ImageInfo);

		FirmwareManagementProtocol->GetImageInfo(
											FirmwareManagementProtocol,
											&ImageInfoSize,
											ImageInfo,
											&DescriptorVersion,
											&DescriptorCount,
											&DescriptorSize,
											&PackageVersion,
											&PackageVersionName
											);
	}

	Print(L"ImageInfoSize = %d\r\n",ImageInfoSize);	
	Print(L"DescriptorVersion = %d\r\n",DescriptorVersion);
	Print(L"DescriptorCount = %d\r\n",DescriptorCount);
	Print(L"DescriptorSize = %d\r\n",DescriptorSize);
	Print(L"PackageVersion = %d\r\n",PackageVersion);
	Print(L"PackageVersionName = %s\r\n",PackageVersionName);
}

