#ifndef _DEBUG_MEM_DUMP_H
#define _DEBUG_MEM_DUMP_H

typedef struct
{
	UINT16 Year;
	UINT8 Month;
	UINT8 Day;
	UINT8 Hour;
	UINT8 Min;
	UINT8 Sec;
}BIOS_BUILD_TIME;

typedef struct 
{
	UINT8  Major_Version;
	UINT8  Minor_Version;
}BIOS_VERSION;

typedef	struct
{
	BIOS_VERSION 	BIOSVersion;
	BIOS_BUILD_TIME BIOSBuildTime;
}SYSTEM_BIOS_INFO;

typedef struct
{
	UINT16	TotalLength;		//Total debug memory length
	UINT16  DebugNumbers;		//Current Number of Debugmem
	UINT32  FreeMemStartAddress;// Memory Address of Free memory
	SYSTEM_BIOS_INFO BIOSInfo;
}DEBUG_MEM_HEADER;


typedef struct
{
	UINT16 NumberOfDebug;		//Debug NO.
	UINT16 DebugLength;			//Debug length
	UINT32 Reserved;
}DEBUG_MEM_BUFFER_HEADER;

typedef struct 
{
	DEBUG_MEM_BUFFER_HEADER DebugMemBufferHeader;
	CHAR8 *Buffer;				//Debug info
}DEBUG_MEM_BUFFER;

typedef struct
{
	DEBUG_MEM_HEADER DebugMemHeader;
	DEBUG_MEM_BUFFER *DebugMemBuffer;
}OEM_DEBUG_MEMORY;

#define BYD_DXE_PROTOCOL_GUID \
        { 0xEC87D643, 0xEBA4, 0x4BB5, 0xA1, 0xE5, 0x3F, 0x3E, 0x36, 0xB2, 0x0D, 0xA9 }


typedef EFI_STATUS
(EFIAPI *CREATE_NEW_DEBUG_MEM)
(IN UINT16 Length,IN CHAR8 *Str);

typedef EFI_STATUS 
(EFIAPI *ADD_STR_2_DEBUG_MEM)
(IN UINT16 StrSize,IN CHAR8 *Str);

typedef EFI_STATUS
(EFIAPI *DEBUG_MEM_DUMP)();

typedef struct
{
	CREATE_NEW_DEBUG_MEM Create_New_Debug_Mem;
	ADD_STR_2_DEBUG_MEM  Add_Str_2_Debug_Mem;
	DEBUG_MEM_DUMP		 Debug_Mem_Dump;	
}BYD_DXE_PROTOCOL_STRUCT;

#endif
