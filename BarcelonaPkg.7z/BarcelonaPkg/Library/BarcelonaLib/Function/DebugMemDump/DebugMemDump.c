#include <Uefi.h>
#include <Library/PcdLib.h>
#include <Library/UefiLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/IoLib.h>
#include <Library/ShellLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiRuntimeLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/MemoryAllocationLib.h>

#include <sstd.h>
#include <EricTestBase.h>
#include "PciBus.h"
#include "Variable.h"
#include "sstd.h"
#include <DebugMemDump.h>

EFI_GUID BydDxeProtocolGuid = BYD_DXE_PROTOCOL_GUID;

EFI_STATUS DebugMemDump()
{
	EFI_STATUS 		 Status = EFI_SUCCESS;
	OEM_DEBUG_MEMORY *OemDebugMemory;
    DEBUG_MEM_BUFFER *DebugMemBuffer;
	OemVariableDef   OemVariable;
	UINT16			 Index=0;
	UINT64		     DebugMemAddress = 0;
	BIOS_VERSION	 Version;
	BIOS_BUILD_TIME  BuildTime;

	CHAR16 	*Buffer = NULL;
	UINT16 	BufferSize =0x400;// = DebugMemBuffer->DebugMemBufferHeader.DebugLength;
	UINT64 	AddressShift;		//Add for DebugBuffer Memory shift, the reason unknow.
	UINT64 	AddressShift_Buffer;// = (UINT64)DebugMemBuffer + sizeof(DEBUG_MEM_BUFFER_HEADER);
	UINT16  i;

	Status = GetOemVariable(&OemVariable);

	if(EFI_ERROR(Status))
	{
		Print(L"Get Oem variable fail, please check BIOS first!\r\n");
		return 1;
	}

	DebugMemAddress = (UINT64)OemVariable.OemDebugBufferAddr;

	OemDebugMemory = (OEM_DEBUG_MEMORY*)DebugMemAddress;
	DebugMemBuffer = (DEBUG_MEM_BUFFER*)(DebugMemAddress + sizeof(DEBUG_MEM_HEADER));	//Get First Debug Buffer
	
	if((OemDebugMemory->DebugMemHeader.FreeMemStartAddress == 0)||(OemDebugMemory->DebugMemHeader.TotalLength ==0))
	{
		Print(L"Get Oem Debug Memory fail, please check BIOS\r\n");
		return 2;
	}

	Version = OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSVersion;
	BuildTime = OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSBuildTime;

	Print(L"System BIOS debug memory:\r\n");
	Print(L"BIOS_Version:   %x.%0x\r\n",Version.Major_Version,Version.Minor_Version);
	Print(L"BIOS_Build_Time:%04d-%02d-%02d %02d:%02d:%02d\r\n",BuildTime.Year,BuildTime.Month,BuildTime.Day,BuildTime.Hour,BuildTime.Min,BuildTime.Sec);
	Print(L"MemoryAddress = 0x%08x\r\n",(UINT64)OemDebugMemory);
	Print(L"MemorySize    = 0x%x\r\n",OemDebugMemory->DebugMemHeader.TotalLength);
	Print(L"DebugNumbers  = %x\r\n",OemDebugMemory->DebugMemHeader.DebugNumbers);


	gBS->AllocatePool(EfiRuntimeServicesData,BufferSize,&Buffer);

	for(Index=0; Index < OemDebugMemory->DebugMemHeader.DebugNumbers; Index++)
	{	
		BufferSize = DebugMemBuffer->DebugMemBufferHeader.DebugLength;
		AddressShift_Buffer = (UINT64)DebugMemBuffer + sizeof(DEBUG_MEM_BUFFER_HEADER);

		gBS->SetMem(Buffer,BufferSize*2,0);
	
		OemAscii2Unicode(Buffer, (CHAR8*)AddressShift_Buffer);
		
		Print(L"DebugNo:%d; Length=0x%x\r\n",DebugMemBuffer->DebugMemBufferHeader.NumberOfDebug,BufferSize);
		Print(L"Address=0x%x\r\n",DebugMemBuffer);
		for(i=0;i<BufferSize;i++)
		{
			Print(L"%c",*(Buffer+i));
		}
		Print(L"\r\n");
		
		AddressShift = (UINT64)DebugMemBuffer;
		AddressShift+=(BufferSize + sizeof(DEBUG_MEM_BUFFER_HEADER));
		DebugMemBuffer = (DEBUG_MEM_BUFFER*)AddressShift;		
	}

	gBS->FreePool(Buffer);
	
	return Status;
}

EFI_STATUS DebugMemDump1()
{
	EFI_STATUS 				Status;
	BYD_DXE_PROTOCOL_STRUCT *BydDxeProtocol;

	Status = gBS->LocateProtocol(
						&BydDxeProtocolGuid,
						NULL,
						&BydDxeProtocol);
	
	if(EFI_ERROR(Status))
	{
		Print(L"Locate BydDxeProtocol fail,Status = %d!\r\n",Status);
		return 1;
	}

	Status = BydDxeProtocol->Debug_Mem_Dump();

	return Status;
}


