#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <Protocol/EfiShell.h>
#include <Library/ShellLib.h>
#include <EricTestBase.h>


EFI_DEVICE_PATH_PROTOCOL *
EFIAPI
ShellGetDevicePath(IN CHAR16 *DeviceName)
{
	if(gEfiShellProtocol != NULL)
		return (gEfiShellProtocol->GetDevicePathFromFilePath(DeviceName));

	if(mEfiShellEnvironment2 != NULL)
		return (mEfiShellEnvironment2->NameToPath(DeviceName));

	return NULL;	
}

EFI_STATUS 
EFIAPI
OEMLoadImage(IN EFI_HANDLE         ImageHandle)
{
	EFI_STATUS 					Status;
//	EFI_HANDLE					Handle;
	EFI_LOADED_IMAGE_PROTOCOL	*ImageInfo = NULL;
	UINTN 						Argc;
    CHAR16** 					Argv;
	EFI_DEVICE_PATH_PROTOCOL	*DevicePath;
	EFI_HANDLE					NewHandle;
	UINTN         				ExitDataSizePtr;
    
	GetParameter(ImageHandle, &Argc, &Argv);

	DevicePath = ShellGetDevicePath(L"Time.efi");

	Status = gBS->LoadImage(
							FALSE,
							gImageHandle,
							DevicePath,
							NULL,
							0,
							&NewHandle);
	if(EFI_ERROR(Status))
	{
		if(NewHandle != NULL)
		{
			gBS->UnloadImage(NewHandle);
		}
		Print(L"Error during LoadImage [%X]\n",Status);
		return Status;
	}

	Status = gBS->HandleProtocol(
								NewHandle,
								&gEfiLoadedImageProtocolGuid,
								&ImageInfo);
	if(EFI_ERROR(Status))
	{
		Print(L"Handle LoadImageProtocol fail\n");
		return Status;
	}
	
	Print(L"ImageBase [%lx]\n",ImageInfo->ImageBase);
	Print(L"ImageSize [%lx]\n",ImageInfo->ImageSize);

	Status = gBS->StartImage(
							NewHandle,
							&ExitDataSizePtr,
							NULL);
	if(EFI_ERROR(Status))
	{
		if(NewHandle != NULL)
		{
			gBS->UnloadImage(NewHandle);
		}
		Print(L"Error during StartImage [%x]\n",Status);
		return Status;
	}

	gBS->UnloadImage(NewHandle);
	return Status;
}