#ifndef _REGISTER_HOTKEY_H
#define _REGISTER_HOTKEY_H

extern void HotKeyNotifyFunction();



#endif

