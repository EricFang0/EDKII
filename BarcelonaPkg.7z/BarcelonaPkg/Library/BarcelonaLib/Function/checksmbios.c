/** @file
  This sample application bases on HelloWorld PCD setting 
  to print "UEFI Hello World!" to the UEFI Console.

  Copyright (c) 2006 - 2008, Intel Corporation. All rights reserved.<BR>
  This program and the accompanying materials                          
  are licensed and made available under the terms and conditions of the BSD License         
  which accompanies this distribution.  The full text of the license may be found at        
  http://opensource.org/licenses/bsd-license.php                                            

  THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,                     
  WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.             

**/

#include <Uefi.h>
#include <Library/PcdLib.h>
#include <Library/BaseLib.h>

#include <Library/UefiLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <IndustryStandard/SmBios.h>
#include <Guid/SmBios.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/PcdLib.h>
#include <Library/IoLib.h>
#include <Library/PrintLib.h>
#include <Library/DebugLib.h>
#include <Library/PcdLib.h>
#include <Protocol/SmBios.h>

//#include <string.h>
#include "TestFunction.h"
#include "Checksmbios.h"		//Eric add

#include <sstd.h>

#define DMI_SUCCESS                     0x00
#define DMI_UNKNOWN_FUNCTION            0x81
#define DMI_FUNCTION_NOT_SUPPORTED      0x82
#define DMI_INVALID_HANDLE              0x83
#define DMI_BAD_PARAMETER               0x84
#define DMI_INVALID_SUBFUNCTION         0x85
#define DMI_NO_CHANGE                   0x86
#define DMI_ADD_STRUCTURE_FAILED        0x87
#define DMI_READ_ONLY                   0x8D
#define DMI_LOCK_NOT_SUPPORTED          0x90
#define DMI_CURRENTLY_LOCKED            0x91
#define DMI_INVALID_LOCK                0x92

#define INVALID_HANDLE                  (UINT16) (-1)

#define EFI_SMBIOSERR(val)              EFIERR (0x30000 | val)

#define EFI_SMBIOSERR_FAILURE           EFI_SMBIOSERR (1)
#define EFI_SMBIOSERR_STRUCT_NOT_FOUND  EFI_SMBIOSERR (2)
#define EFI_SMBIOSERR_TYPE_UNKNOWN      EFI_SMBIOSERR (3)
#define EFI_SMBIOSERR_UNSUPPORTED       EFI_SMBIOSERR (4)

#define M_B4 1
#define M_B5 2
#define M_B6 3
#define M_F1 4
#define M_F2 5
#define M_H1 6
#define M_H2 7
#define M_H3 8
#define M_B65 9
#define M_B7 10
#define M_B8 11
#define M_F25 12
#define M_H4 13
#define M_C1 14
#define M_F3 15
#define M_F35 16




#define SMBIOS_TABLE_GUID \
  { \
    0xeb9d2d31, 0x2d88, 0x11d3, {0x9a, 0x16, 0x0, 0x90, 0x27, 0x3f, 0xc1, 0x4d } \
  }
  
EFI_GUID gEfiSmbiosTableGuid = SMBIOS_TABLE_GUID;

STATIC UINT8                    mInit         = 0;
STATIC SMBIOS_TABLE_ENTRY_POINT *mSmbiosTable = NULL;
STATIC SMBIOS_STRUCTURE_POINTER m_SmbiosStruct;
STATIC SMBIOS_STRUCTURE_POINTER *mSmbiosStruct = &m_SmbiosStruct;


/**
  Init the SMBIOS VIEW API's environment.

  @retval EFI_SUCCESS  Successful to init the SMBIOS VIEW Lib.
**/
EFI_STATUS
LibSmbiosInit (
  VOID
  )
{
  EFI_STATUS  Status;

  //
  // Init only once
  //
  if (mInit == 1) {
    return EFI_SUCCESS;
  }
  //
  // Get SMBIOS table from System Configure table
  //GetSystemConfigurationTable
  Status = EfiGetSystemConfigurationTable(&gEfiSmbiosTableGuid, (VOID**)&mSmbiosTable);

  if (mSmbiosTable == NULL) {
    //ShellPrintHiiEx(-1,-1,NULL,STRING_TOKEN (STR_SMBIOSVIEW_LIBSMBIOSVIEW_CANNOT_GET_TABLE), gShellDebug1HiiHandle);
    return EFI_NOT_FOUND;
  }

  if (EFI_ERROR (Status)) {
    //ShellPrintHiiEx(-1,-1,NULL,STRING_TOKEN (STR_SMBIOSVIEW_LIBSMBIOSVIEW_GET_TABLE_ERROR), gShellDebug1HiiHandle, Status);
    return Status;
  }
  //
  // Init SMBIOS structure table address
  //
  mSmbiosStruct->Raw  = (UINT8 *) (UINTN) (mSmbiosTable->TableAddress);

  mInit               = 1;
  return EFI_SUCCESS;
}

/**
  Cleanup the Smbios information.
**/
VOID
LibSmbiosCleanup (
  VOID
  )
{
  //
  // Release resources
  //
  if (mSmbiosTable != NULL) {
    mSmbiosTable = NULL;
  }

  mInit = 0;
}

/**
  Get the entry point structure for the table.

  @param[out] EntryPointStructure  The pointer to populate.
**/
VOID
LibSmbiosGetEPS (
  OUT SMBIOS_TABLE_ENTRY_POINT **EntryPointStructure
  )
{
  //
  // return SMBIOS Table address
  //
  *EntryPointStructure = mSmbiosTable;
}

/**
  Return SMBIOS string for the given string number.

  @param[in] Smbios         Pointer to SMBIOS structure.
  @param[in] StringNumber   String number to return. -1 is used to skip all strings and
                            point to the next SMBIOS structure.

  @return Pointer to string, or pointer to next SMBIOS strcuture if StringNumber == -1
**/
CHAR8*
LibGetSmbiosString (
  IN  SMBIOS_STRUCTURE_POINTER    *Smbios,
  IN  UINT16                      StringNumber
  )
{
  UINT16  Index;
  CHAR8   *String;

  //ASSERT (Smbios != NULL);

  //
  // Skip over formatted section
  //
  String = (CHAR8 *) (Smbios->Raw + Smbios->Hdr->Length);

  //
  // Look through unformated section
  //
  for (Index = 1; Index <= StringNumber; Index++) {
    if (StringNumber == Index) {
      return String;
    }
    //
    // Skip string
    //
    for (; *String != 0; String++);
    String++;

    if (*String == 0) {
      //
      // If double NULL then we are done.
      //  Return pointer to next structure in Smbios.
      //  if you pass in a -1 you will always get here
      //
      Smbios->Raw = (UINT8 *)++String;
      return NULL;
    }
  }

  return NULL;
}

/**
    Get SMBIOS structure for the given Handle,
    Handle is changed to the next handle or 0xFFFF when the end is
    reached or the handle is not found.

    @param[in, out] Handle     0xFFFF: get the first structure
                               Others: get a structure according to this value.
    @param[out] Buffer         The pointer to the pointer to the structure.
    @param[out] Length         Length of the structure.

    @retval DMI_SUCCESS   Handle is updated with next structure handle or
                          0xFFFF(end-of-list).

    @retval DMI_INVALID_HANDLE  Handle is updated with first structure handle or
                                0xFFFF(end-of-list).
**/
EFI_STATUS
LibGetSmbiosStructure (
  IN  OUT UINT16  *Handle,
  OUT UINT8       **Buffer,
  OUT UINT16      *Length
  )
{
  SMBIOS_STRUCTURE_POINTER  Smbios;
  SMBIOS_STRUCTURE_POINTER  SmbiosEnd;
  UINT8                     *Raw;

  if (*Handle == INVALID_HANDLE) {
    *Handle = mSmbiosStruct->Hdr->Handle;
    return DMI_INVALID_HANDLE;
  }

  if ((Buffer == NULL) || (Length == NULL)) {
    // ShellPrintHiiEx(-1,-1,NULL,STRING_TOKEN (STR_SMBIOSVIEW_LIBSMBIOSVIEW_NO_BUFF_LEN_SPEC), gShellDebug1HiiHandle);
    return DMI_INVALID_HANDLE;
  }

  *Length       = 0;
  Smbios.Hdr    = mSmbiosStruct->Hdr;
  SmbiosEnd.Raw = Smbios.Raw + mSmbiosTable->TableLength;
  while (Smbios.Raw < SmbiosEnd.Raw) {
    if (Smbios.Hdr->Handle == *Handle) {
      Raw = Smbios.Raw;
      //
      // Walk to next structure
      //
      LibGetSmbiosString (&Smbios, (UINT16) (-1));
      //
      // Length = Next structure head - this structure head
      //
      *Length = (UINT16) (Smbios.Raw - Raw);
      *Buffer = Raw;
      //
      // update with the next structure handle.
      //
      if (Smbios.Raw < SmbiosEnd.Raw) {
        *Handle = Smbios.Hdr->Handle;
      } else {
        *Handle = INVALID_HANDLE;
      }
      return DMI_SUCCESS;
    }
    //
    // Walk to next structure
    //
    LibGetSmbiosString (&Smbios, (UINT16) (-1));
  }

  *Handle = INVALID_HANDLE;
  return DMI_INVALID_HANDLE;
}

INTN
EFIAPI
MemCompareMem (
  IN      CONST VOID                *DestinationBuffer,
  IN      CONST VOID                *SourceBuffer,
  IN      UINTN                     Length
  )
{
  while ((--Length != 0) &&
         (*(INT8*)DestinationBuffer == *(INT8*)SourceBuffer)) {
    DestinationBuffer = (INT8*)DestinationBuffer + 1;
    SourceBuffer = (INT8*)SourceBuffer + 1;
  }
  return (INTN)*(UINT8*)DestinationBuffer - (INTN)*(UINT8*)SourceBuffer;
}


EFI_STATUS
EFIAPI
CheckSMBIOS (void)
  {
	UINT32 						Index;
	UINT64 						microcodeVersion;
	SMBIOS_STRUCTURE_POINTER  	SmbiosStruct;
	SMBIOS_TABLE_ENTRY_POINT  	*SMBiosTable;
	UINT8  						SmbiosMajorVersion;
	UINT8  						SmbiosMinorVersion;
	Index = 0;

  //
  // Three PCD type (FeatureFlag, UINT32 and String) are used as the sample.
  //
  if (FeaturePcdGet (PcdHelloWorldPrintEnable)) {
  	for (Index = 0; Index < PcdGet32 (PcdHelloWorldPrintTimes); Index ++) {
  	  //
  	  // Use UefiLib Print API to print string to UEFI console
  	  //
   		//Print ((CHAR16*)PcdGetPtr (PcdHelloWorldPrintString));
    }
  }
  microcodeVersion=1;
  microcodeVersion=AsmReadMsr64(0x8b);
 //Print(L"MCU PATCH:%x",microcodeVersion);

  LibSmbiosInit();
  SMBiosTable = NULL;
  LibSmbiosGetEPS (&SMBiosTable);
  if (SMBiosTable == NULL) {
    Print(L"NO SMBIOS FOUND");
    return EFI_BAD_BUFFER_SIZE;
  }

  if (MemCompareMem (SMBiosTable->AnchorString, "_SM_",4) == 0) {
    //
    // Have got SMBIOS table
    //
    SmbiosMajorVersion = SMBiosTable->MajorVersion;
    SmbiosMinorVersion = SMBiosTable->MinorVersion;
    //Print(L"SMBIOSVER:%x.%x",SmbiosMajorVersion,SmbiosMinorVersion);
  }

  {  
    UINT16                    Handle;
  	UINT8                     *Buffer;
  	UINT16                    Length;
  //UINT16                    Offset;
  	UINT16                    Index1;
  	UINT32   count;
  	Handle    = 0;

  //*Handle = SMBiosTable->  //->Handle;
    for (Index1 = 0; Index1 < SMBiosTable->NumberOfSmbiosStructures; Index1++) {
      //
      // if reach the end of table, break..
      //
      if (Handle == INVALID_HANDLE) {
        break;
      }
      //
      // handle then point to the next!
      //
      if (LibGetSmbiosStructure (&Handle, &Buffer, &Length) != DMI_SUCCESS) {
        break;
      }
	  //Print(L"\nIndex %x\n",Index);
      SmbiosStruct.Raw = Buffer;
	  
	  if(Length >13) Length-=13;
	  if(Index1==1)
	  {		  		
		  for(count=0;count<Length;count++)
		  {
				  //Print(L"%02x-",Buffer[count]);
			  if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x20 && Buffer[count+4]==0x50 &&Buffer[count+5]==0x72 && Buffer[count+6]==0x6f && Buffer[count+7]==0x00 && Buffer[count+8]==0x31 && Buffer[count+9]==0x2e && Buffer[count+10]==0x30)
			  {
				  Print(L"\nF1\n");
				  return M_F1;
			  }
			  if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x20 && Buffer[count+4]==0x50 &&Buffer[count+5]==0x72 && Buffer[count+6]==0x6f && Buffer[count+7]==0x00 && Buffer[count+8]==0x32 && Buffer[count+9]==0x2e && Buffer[count+10]==0x30)
			  {
				  Print(L"\nF2\n");
				  return M_F2;
			  }	
			   if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x20 && Buffer[count+4]==0x50 &&Buffer[count+5]==0x72 && Buffer[count+6]==0x6f && Buffer[count+7]==0x00 && Buffer[count+8]==0x32 && Buffer[count+9]==0x2e && Buffer[count+10]==0x35)
			  {
				  Print(L"\nF2.5\n");
				  return M_F25;
			  }	
			  if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x00 && Buffer[count+4]==0x34 &&Buffer[count+5]==0x2e && Buffer[count+6]==0x30)
			  {
				  Print(L"\nB4\n");
				  return M_B4;
			  }
			  if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x00 && Buffer[count+4]==0x35 &&Buffer[count+5]==0x2e && Buffer[count+6]==0x30)
			  {
				  Print(L"\nB5\n");
				  return M_B5;
			  }
				if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x00 && Buffer[count+4]==0x36 &&Buffer[count+5]==0x2e && Buffer[count+6]==0x30)
			  {
				  Print(L"\nB6\n");
				  return M_B6;
			  }
			  if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x20 && Buffer[count+4]==0x53 &&Buffer[count+5]==0x74 && Buffer[count+6]==0x65 && Buffer[count+7]==0x61 && Buffer[count+8]==0x6C && Buffer[count+9]==0x74 && Buffer[count+10]==0x68 && Buffer[count+11]==0x00 && Buffer[count+12]==0x31 && Buffer[count+13]==0x2E && Buffer[count+14]==0x30 )
			  {
				  Print(L"\nH1\n");
				  return M_H1;
			  }
				if(Buffer[count]==0x61 && Buffer[count+1]==0x64  && Buffer[count+2]==0x65 && Buffer[count+3]==0x20 && Buffer[count+4]==0x53 &&Buffer[count+5]==0x74 && Buffer[count+6]==0x65 && Buffer[count+7]==0x61 && Buffer[count+8]==0x6C && Buffer[count+9]==0x74 && Buffer[count+10]==0x68 && Buffer[count+11]==0x00 && Buffer[count+12]==0x32 && Buffer[count+13]==0x2E && Buffer[count+14]==0x30 )
			  {
				  Print(L"\nH2\n");
				  return M_H2;
			  }
			  if(Buffer[count]=='a' && Buffer[count+1]=='d'  && Buffer[count+2]=='e' && Buffer[count+3]==0x20 && Buffer[count+4]=='S' &&Buffer[count+5]=='t' && Buffer[count+6]=='e' && Buffer[count+7]=='a' && Buffer[count+8]=='l' && Buffer[count+9]=='t' && Buffer[count+10]=='h' && Buffer[count+11]==0x00 && Buffer[count+12]=='3' && Buffer[count+13]=='.' && Buffer[count+14]=='0' )
			  {				
					Print(L"\nH3\n");
				  return M_H3;
			  }
			  if(Buffer[count]=='a' && Buffer[count+1]=='d'  && Buffer[count+2]=='e' && Buffer[count+3]==0x20 && Buffer[count+4]=='S' &&Buffer[count+5]=='t' && Buffer[count+6]=='e' && Buffer[count+7]=='a' && Buffer[count+8]=='l' && Buffer[count+9]=='t' && Buffer[count+10]=='h' && Buffer[count+11]==0x00 && Buffer[count+12]=='4' && Buffer[count+13]=='.' && Buffer[count+14]=='0' )
			  {				
					Print(L"\n   H4 \n");
				  return M_H4;
			  }
			  
		  }
	  }
	}
  }

  return EFI_DEVICE_ERROR;
  }
  

  