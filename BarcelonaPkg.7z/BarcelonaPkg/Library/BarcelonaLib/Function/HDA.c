/** @file
 **/
#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/IoLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiRuntimeLib.h>
#include  <Library/ShellCEntryLib.h>		//for 

#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <Protocol/EfiShell.h>
#include <Library/ShellLib.h>
#include <EricTestBase.h>
#include <HDA.h>
#include <Library/TimerLib.h>
#include <PciCf8Lib.h>


#if 1

#define HDA_MAX_LOOP_TIME            200
#define HDA_WAIT_PERIOD              5

#define HDA_MAX_SDI_NUMBER           3
#define HDA_MAX_SDI_MASK             ((1 << HDA_MAX_SDI_NUMBER) - 1)
#define HDA_SDI_0_HDALINK            0
#define HDA_SDI_1_HDALINK            1
#define HDA_SDI_2_IDISPLINK          2

#define HDA_PCI_BUS					0x0
#define HDA_PCI_Device				0x1F
#define HDA_PCI_Function			0x3

/**
  Get HDA BAR Address and enable BAR space.

  @param[in] StatusReg            The register address to read the status
  @param[in] PollingBitMap        The bit mapping for polling
  @param[in] PollingData          The Data for polling

  @retval EFI_SUCCESS             The function completed successfully
  @retval EFI_TIMEOUT             Polling the bit map time out
**/
EFI_STATUS GetHDABAR(OUT UINT32 * HdaBar)
{
	UINTN					HdaPciBase;

	HdaPciBase = ICL_PCIeMMIOBaseAddress + PCI_CF8_LIB_ADDRESS(HDA_PCI_BUS,HDA_PCI_Device,HDA_PCI_Function,0);		

	*HdaBar = (MmioRead32(HdaPciBase + 0x10)&0xFFFFFFF0);

	MmioWrite32(HdaPciBase + 0x04, 0x02);					//Write BAR Enable,In HDA PCI ConfigureSpace Offset 0x04

	return EFI_SUCCESS;
}

/**
  Polling the Status bit.
  Maximum polling time (us) equals HDA_MAX_LOOP_TIME * HDA_WAIT_PERIOD.

  @param[in] StatusReg            The register address to read the status
  @param[in] PollingBitMap        The bit mapping for polling
  @param[in] PollingData          The Data for polling

  @retval EFI_SUCCESS             The function completed successfully
  @retval EFI_TIMEOUT             Polling the bit map time out
**/
EFI_STATUS
StatusPolling (
  IN      UINT32          StatusReg,
  IN      UINT32          PollingBitMap,
  IN      UINT32          PollingData
  )
{
  UINT32  LoopTime;

  for (LoopTime = 0; LoopTime < HDA_MAX_LOOP_TIME; LoopTime++) {
    if ((MmioRead32 (StatusReg) & PollingBitMap) == PollingData) {
      break;
    } else {
      OemDelay_ms (HDA_WAIT_PERIOD);
    }
  }

  if (LoopTime >= HDA_MAX_LOOP_TIME) {
    return EFI_TIMEOUT;
  }

  return EFI_SUCCESS;
}

/**
  Send the command to the codec via the Immediate Command mechanism is written
  to the IC register

  @param[in] HdaBar                     Base address of Intel HD Audio memory mapped configuration registers
  @param[in, out] CodecCommandData      The Codec Command to be sent to the codec
  @param[in] ReadBack                   Whether to get the response received from the codec

  @retval EFI_DEVICE_ERROR              Device status error, operation failed
  @retval EFI_SUCCESS                   The function completed successfully
**/
EFI_STATUS
SendCodecCommand (
  IN      UINT32          HdaBar,
  IN OUT  UINT32          *CodecCommandData,
  IN      BOOLEAN         ReadBack
  )
{
  EFI_STATUS  Status;

  Status = StatusPolling (HdaBar + R_HDA_MEM_ICS, (UINT16) B_HDA_MEM_ICS_ICB, (UINT16) 0);
  if (EFI_ERROR (Status)) {
    Print (L"ICB bit is not zero before SendCodecCommand! \n");
    return EFI_DEVICE_ERROR;
  }

  MmioWrite32 (HdaBar + R_HDA_MEM_IC, *CodecCommandData);
  MmioOr16 ((UINTN) (HdaBar + R_HDA_MEM_ICS), (UINT16) ((B_HDA_MEM_ICS_IRV | B_HDA_MEM_ICS_ICB)));

  Status = StatusPolling (HdaBar + R_HDA_MEM_ICS, (UINT16) B_HDA_MEM_ICS_ICB, (UINT16) 0);
  if (EFI_ERROR (Status)) {
    MmioAnd16 ((UINTN) (HdaBar + R_HDA_MEM_ICS), (UINT16) ~(B_HDA_MEM_ICS_ICB));
    return Status;
  }

  if (ReadBack == TRUE) {
    if ((MmioRead16 (HdaBar + R_HDA_MEM_ICS) & B_HDA_MEM_ICS_IRV) != 0) {
      *CodecCommandData = MmioRead32 (HdaBar + R_HDA_MEM_IR);
    } else {
      Print (L"SendCodecCommand: ReadBack fail! \n");
      return EFI_DEVICE_ERROR;
    }
  }

  return EFI_SUCCESS;
}


/**
  Detect active HDA codec links
    BIT2(100) -- SDI2
    BIT1(010) -- SDI1
    BIT0(001) -- SDI0

  @param[in]   HdaBar               Memory Space Base Address

  @retval      UINT8                Azalia SDI active codec mask
**/
UINT8
DetectCodecs (
  IN UINT32       HdaBar
  )
{
  UINT32     LoopTime;
  UINT8      AzaliaSdiMask;
  UINT8      TmpPollingReg;

  AzaliaSdiMask = 0;

  for (LoopTime = 0; LoopTime < HDA_MAX_LOOP_TIME; LoopTime++) {
    TmpPollingReg = (UINT8) (MmioRead8 (HdaBar + R_HDA_MEM_WAKESTS) & HDA_MAX_SDI_MASK);
    if (TmpPollingReg != 0 && (TmpPollingReg == AzaliaSdiMask)) {
      break;
    } else {
      AzaliaSdiMask = TmpPollingReg;
    }
    OemDelay_ms (HDA_WAIT_PERIOD);
  }
  return AzaliaSdiMask;
}

/**
  For each codec, a predefined codec verb table should be programmed.

  @param[in]   HdaBar               Memory Space Base Address
  @param[in]   AzaliaSdiNum         Azalia SDI Line Number
  @param[out]  CodecVendorId        Codec Vendor Id
  @param[out]  CodecRevisionId      Codec Revision Id

  @retval EFI_SUCCESS               The function completed successfully
  @retval EFI_DEVICE_ERROR          Device status error, operation failed
**/
EFI_STATUS
GetCodecId (
  IN  UINT32     HdaBar,
  IN  UINT8      AzaliaSdiNum,
  OUT UINT32*    CodecVendorId,
  OUT UINT32*    CodecRevisionId
  )
{
  EFI_STATUS  Status;
  ///
  /// Verb:  31~28   27  26~20                   19~0
  ///         CAd    1    NID   Verb Command and data
  ///       0/1/2
  ///
  /// Read the Vendor ID/Device ID pair from the attached codec (ParameterId = 0x00)
  ///
  *CodecVendorId = 0x000F0000 | (AzaliaSdiNum << 28);
  Status = SendCodecCommand (HdaBar, CodecVendorId, TRUE);
  if (EFI_ERROR (Status)) {
    Print (L"SDI#%d Error: Reading the Codec Vendor ID/Device ID fail!\n", AzaliaSdiNum);
    return Status;
  }
  ///
  /// Read the Revision ID from the attached codec (ParameterId = 0x02)
  ///
  *CodecRevisionId = 0x000F0002 | (AzaliaSdiNum << 28);
  Status = SendCodecCommand (HdaBar, CodecRevisionId, TRUE);
  if (EFI_ERROR (Status)) {
    Print ( L"SDI#%d Error: Reading the Codec Revision ID fail!\n", AzaliaSdiNum);
    return Status;
  }

  *CodecRevisionId = (*CodecRevisionId >> 8) & 0xFF;

  return EFI_SUCCESS;
}


EFI_STATUS
CheckCodec()
{
	UINT32    CodecVendorId;
  	UINT32    CodecRevisionId;
	UINT32	  HdaBar;
	UINT8     AzaliaSdiMask;

  	GetHDABAR(&HdaBar);

  	AzaliaSdiMask = DetectCodecs(HdaBar);

  	Print(L"\r\n");

  	if((AzaliaSdiMask&0x01) == 0x01)
  	{
		GetCodecId(HdaBar, 0, &CodecVendorId,&CodecRevisionId);
		Print(L"Codec on SDI0 : VendorId: %08x\r\n",CodecVendorId);
  	}else
  		Print(L"No Codec link on HDA SDI0\r\n");

  	if((AzaliaSdiMask&0x02) == 0x02)
  	{
		GetCodecId(HdaBar, 1, &CodecVendorId,&CodecRevisionId);
		Print(L"Codec on SDI1 : VendorId: %08x\r\n",CodecVendorId);
  	}else
  		Print(L"No Codec link on HDA SDI1\r\n");

  	if((AzaliaSdiMask&0x04) == 0x04)
  	{
		GetCodecId(HdaBar, 2, &CodecVendorId,&CodecRevisionId);
		Print(L"Codec on SDI2 : VendorId: %08x\r\n",CodecVendorId);
  	}else
  		Print(L"No Codec link on HDA SDI2\r\n");
  		
	Print(L"\r\n");

  	return EFI_SUCCESS;
}

#else



#endif
