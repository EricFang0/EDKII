#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>

#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <time.h>
#include <Protocol/EfiShell.h>
#include <Library/ShellLib.h>

#include <SimpleFileSystem.h>
#include <Protocol/BlockIo.h>
#include <Library/DevicePathLib.h>
#include <Library/HandleParsingLib.h>
#include <Library/SortLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/BaseMemoryLib.h>
#include <LoadedImage.h>

extern EFI_BOOT_SERVICES         *gBS;
extern EFI_SYSTEM_TABLE      	 *gST;
extern EFI_RUNTIME_SERVICES      *gRT;

extern EFI_HANDLE         		 gImageHandle;
extern EFI_SHELL_ENVIRONMENT2 	 *mEfiShellEnvironment2;
STATIC CONST UINTN 				 SecondsToNanoSeconds = 500000;

void EFIAPI 
TimeOut(IN EFI_EVENT Event,
			IN VOID *Context
			)
{
	EFI_TIME ET;
	UINTN x,y;

	//Get current cursor position
	x = gST->ConOut->Mode->CursorColumn;
	y = gST->ConOut->Mode->CursorRow;

	//Move cursor to Right-Up
	gST->ConOut->SetCursorPosition(gST->ConOut,70,0);
	//Output current time
	gRT->GetTime(&ET,NULL);
	
	Print(L"%d:%d:%d--%d:%d:%d",ET.Year,ET.Month,ET.Day,ET.Hour,ET.Minute,ET.Second);

	gST->ConOut->SetCursorPosition(gST->ConOut,x,y);
}

typedef struct{
	UINTN			Signature;
	EFI_HANDLE		Handle;
	UINTN			Type;
	BOOLEAN			Started;
	EFI_IMAGE_ENTRY_POINT		EntryPoint;
	EFI_LOADED_IMAGE_PROTOCOL	Info;
}LOADED_IMAGE_PRIVATE_DATA_TEMP;

#define _CR(Record, TYPE, Field)  ((TYPE *) ((CHAR8 *) (Record) - (CHAR8 *) &(((TYPE *) 0)->Field)))

#define LOADED_IMAGE_PRIVATE_DATA_FROM_THIS(a) \
          _CR(a, LOADED_IMAGE_PRIVATE_DATA_TEMP, Info)


typedef void (*Fun)();

void function()
{
	EFI_STATUS	Status;
	EFI_HANDLE	TimerOne = NULL;

	Print(L"Function called\n");
	Status = gBS->CreateEvent(
							EVT_NOTIFY_SIGNAL|EVT_TIMER,
							TPL_CALLBACK,
							TimeOut,
							NULL,
							&TimerOne
							);
	if(EFI_ERROR(Status))
	{
		Print(L"Creat Event Error\r\n");
	}

	Status = gBS->SetTimer(
						TimerOne,
						TimerPeriodic,
						MultU64x32(SecondsToNanoSeconds, 1)
							);
	if(EFI_ERROR(Status))
	{
		Print(L"Set Timer Error\r\n");
	}
}

// Show Current time on shell
EFI_STATUS EFIAPI APPInMemTest()
{
	EFI_STATUS	Status = EFI_SUCCESS;
	EFI_LOADED_IMAGE_PROTOCOL	*ImageInfo = NULL;
	EFI_HANDLE					Handle = 0;

	LOADED_IMAGE_PRIVATE_DATA_TEMP	*private = NULL;
	Fun							fun;
	UINTN						FunOffset;
	UINTN						FunAddr;

	Status = gBS->HandleProtocol(gImageHandle,&gEfiLoadedImageProtocolGuid,&ImageInfo);
// Function offset in the old image
	FunOffset = (UINTN)function - (UINTN)ImageInfo->ImageBase;
// load the image into memory again
	Status = gBS->LoadImage(FALSE,gImageHandle,NULL,ImageInfo->ImageBase,(UINTN)ImageInfo->ImageSize,&Handle);
// get the newer imageinfo
	Status = gBS->HandleProtocol(Handle,&gEfiLoadedImageProtocolGuid,&ImageInfo);

	private = LOADED_IMAGE_PRIVATE_DATA_FROM_THIS(ImageInfo);
	FunAddr = (UINTN)FunOffset + (UINTN)(ImageInfo->ImageBase);

	fun = (Fun)((UINTN)FunOffset+(UINTN)ImageInfo->ImageBase);
// call the newer function in new image,the new image will be always in memory because it will not be free.
	fun();

	return EFI_SUCCESS;
}	

