/*
;*************************************************************************************
;* Copyright (c) 2020, Huaqin Telecom Technology Co.,Ltd.. All Rights Reserved.
;*************************************************************************************
*/

#ifndef _HQ_EC_LIBRARY_H_
#define _HQ_EC_LIBRARY_H_

#define EC_FLAG_OPEN_ALL_SETUP_PAGE      1

#define ACPI_TIMER_MAX_VALUE  0x1000000

#define KEY_CMD_STATE                     0x64
#define KBC_TIME_OUT                      0x10000
#define KEY_OBF                           1
#define KEY_IBF                           2

#define GET_EC_VERSION_CMD               0x51
#define EC_NOVO_BUTTON_CMD               0x52
#define EC_CRISIS_RECOVERY_CMD           0x53

#define KBC_DATA                          0x60
#define KBC_CMD_STATE                     0x64

#define EC_DATA                           0x62
#define EC_CMD_STATE                      0x66

#define EC_DATA2                          0x68
#define EC_CMD_STATE2                     0x6C

#define EC_READ_ECRAM_CMD                 0x80
#define EC_WRITE_ECRAM_CMD                0x81
     
#define EC_BURST_EN_DATA                  0x82
#define EC_BURST_DIS_DATA                 0x83

#define EC_GET_Q_NUM_DATA                 0x84 //Get Q event Num

#define EC_ACPI_MODE_EN_DATA              0x86
#define EC_ACPI_MODE_DIS_DATA             0x87

#define EC_SMBUS_DEBUG_EN_DATA            0x8E
#define EC_SMBUS_DEBUG_DIS_DATA           0x8F

#define EC_FAN_MAX_SPEED_CMD              0xD8  

#define EC_SYSTEM_NOTIFI_CMD              0x59

//For EC mirror
#define EC_SW_MIRROR_CMD                  0x1D
#define EC_SW_MIRROR_DATA                 0x25C
#define EC_SW_MIRROR_STATE                0x25D

#define ACPI_TIMER_ADDR1                  (PcdGet16(PcdPerfPkgAcpiIoPortBaseAddress) + 0x08)

#define EC_SHARE_MEM_BASE_ADDRESS         0xFEFF0A00
#define EC_SHARE_MEM_CMDB                 (EC_SHARE_MEM_BASE_ADDRESS + 0x00)
#define EC_SHARE_MEM_STAT                 (EC_SHARE_MEM_BASE_ADDRESS + 0x01)
#define EC_SHARE_MEM_NUMB                 (EC_SHARE_MEM_BASE_ADDRESS + 0x02)
#define EC_SHARE_MEM_DAT0                 (EC_SHARE_MEM_BASE_ADDRESS + 0x03)
#define EC_SHARE_MEM_DAT1                 (EC_SHARE_MEM_BASE_ADDRESS + 0x04)
#define EC_SHARE_MEM_DAT2                 (EC_SHARE_MEM_BASE_ADDRESS + 0x05)

#define EC_SHARE_MEM_READ                 0x80
#define EC_SHARE_MEM_WRITE                0x81

//#define HQMemoryRead8(Address)              (*(volatile UINT8 *) (UINTN) (Address))
//#define HQMemoryWrite8(Address, Value)      (*(volatile UINT8 *) (UINTN) (Address) = (Value))
#define HQMemoryRead8(Address)              MmioRead8(Address)
#define HQMemoryWrite8(Address, Value)      MmioWrite8(Address, Value)


#define CRISIS_LED_STATUS                (1 << 5)
#define ON                               0x01

#define LED_NORMAL_BOOT_FLAG             (1 << 4)

EFI_STATUS
HQEcStall(
  IN UINTN Microseconds
  );

EFI_STATUS
HQWaitIBE (
  IN UINT16                         CommandPort
  );

EFI_STATUS
HQWaitOBF (
  IN UINT16                         CommandPort
  );

EFI_STATUS
HQWaitOBE (
  IN UINT16                         CommandPort
);

EFI_STATUS
HQEcCommand (
  IN UINT16                         CommandPort,
  IN UINT16                         DataPort,
  IN UINTN                        NumOfReturnData,
  IN UINT8                          *ReturnData,
  IN UINT8                          Command,
  IN UINTN                          NumOfArgs,
  ...
  );

EFI_STATUS
HQSendEcCommand (
  IN UINT8                          Command
  );

EFI_STATUS
HQReadKbc (
  IN UINT16                         CommandState,
  IN OUT UINT8                      *Data
  );

EFI_STATUS
HQWriteKbc (
  IN UINT16                         CommandState,
  IN UINT8                          Data
  );

VOID
ECRamWrite(
  IN UINT8  Index,
  IN UINT8  Value
  );

UINT8
ECRamRead(
  IN UINT8  Index
  );

EFI_STATUS
HQEcLibReadEcRam(
  IN  UINT8                         Index,
  OUT UINT8                         *Data
  );

EFI_STATUS
HQEcLibWriteEcRam(
  IN UINT8                          Index,
  IN UINT8                          Value
  );

EFI_STATUS
HQEcLibEnableEcAcpiMode(
  IN  BOOLEAN                        EnableACPIMode
  );

EFI_STATUS
HQGetEcVersion (
  IN OUT UINT8                      *EcMajorVersion,
  IN OUT UINT8                      *EcMinorVersion,
  IN OUT UINT8                      *EcTestVersion
  );

EFI_STATUS
ECExternalMemRead (
  IN  UINT64              MemAddress,
  IN  UINT8             DataNum,
  OUT UINT8             * Data      
);

EFI_STATUS
ECExternalMemWrite (
  IN UINT16            MemAddress, 
  IN UINT8             Data
);

/**
  This function is used to set led status for crisis recovery.

  @param[in] LedStatus       1:enter crisis
                             0:crisis done
**/
VOID
SetCrisisLedStatus (
  IN UINT8             LedStatus
);

/**
  This function is used to clear led error status(Set Ec ram 
  0x80 bit4 to notify Ec the DUT has normal boot). 
**/
VOID
ClearErrorLedStatus (
);

VOID
OemPostWdt (
  IN   UINT8        WdtEnable,
  IN   UINT8        Time,
  IN   UINT8        Count
);

VOID
OemPostWdtNotModCount (
  IN   UINT8        WdtEnable,
  IN   UINT8        Time
);
#endif

