#ifndef _TESTFUNCTION_H
#define _TESTFUNCTION_H

extern EFI_STATUS EFIAPI
UefiMain(
        IN EFI_HANDLE           ImageHandle,
        IN EFI_SYSTEM_TABLE     *SystemTable
		);
EFI_STATUS ColdReset (void);		
EFI_STATUS WarmReset (void);
EFI_STATUS Delay10s (void);

extern EFI_STATUS GetEDID();

extern VOID OemReadMem (
  IN  UINT64        Address,
  IN  UINT32         Size,
  IN  VOID          *Buffer
  );

extern CHAR16 * OemAscii2Unicode (
  OUT CHAR16         *UnicodeStr,
  IN  CHAR8          *AsciiStr
  );

EFI_STATUS 
PrintType1String();

#endif