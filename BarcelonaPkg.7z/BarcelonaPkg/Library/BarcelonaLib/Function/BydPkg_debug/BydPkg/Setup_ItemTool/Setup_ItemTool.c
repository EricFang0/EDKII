#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Setup.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>

EFI_GUID gAmiSetupGuid = SETUP_GUID; 

EFI_STATUS Setup_ItemTool(
	IN EFI_HANDLE ImageHandle,
	IN EFI_SYSTEM_TABLE *SystemTable
)
{
	EFI_STATUS      Status;	
	SETUP_DATA    	*SetupData = NULL;
	UINTN         	SetupSize = 0;	
	UINTN         	SetupSize1 = sizeof(SETUP_DATA);	
	UINT32          Attributes;
	
	Status = gRT->GetVariable(L"Setup", &gAmiSetupGuid, &Attributes, &SetupSize, SetupData);


	if(SetupSize!=SetupSize1)
	{
		Print(L"Setup Length not match, Define_length=0x%x, Variable_length=0x%x\r\n",SetupSize1,SetupSize);
		return 1;
	}
	
	if(Status == EFI_BUFFER_TOO_SMALL)
	{
		Status = gBS->AllocatePool(EfiLoaderData,SetupSize,&SetupData);
		gBS->SetMem(SetupData,SetupSize,0);
		
		Status = gRT->GetVariable(L"Setup", &gAmiSetupGuid, &Attributes, &SetupSize, SetupData);

		if(EFI_ERROR(Status))
		{
			Print(L"Get Setup Data Status=%d\r\n",Status);
			return 1;
		}
	}
	
	if(SetupData->ItemShow == 0)
	{
		SetupData->ItemShow = 1;
		Status = gRT->SetVariable(L"Setup", &gAmiSetupGuid, Attributes, SetupSize, SetupData);
		if(EFI_ERROR(Status))
		{
			Print(L"Get Setup Data Status=%d\r\n",Status);
			return 1;
		}
	}
	Print(L"\r\n");
	Print(L"Set Setup All Item Show Success!\r\n");
	Print(L"\r\n");
	gBS->FreePool(SetupData);
		
	return EFI_SUCCESS;
}
