//----------------------------------------------------------------------------
// Include(s)
//----------------------------------------------------------------------------

#include <Efi.h>
#include <Pei.h>
#include <Token.h>
#include <AmiPeiLib.h>
#include <AmiCspLib.h>
#include <Ppi/CrbInfo.h>
#include <Library/BaseMemoryLib.h>
#include <Library/HobLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/PcdLib.h>
#include <Ppi/BydPei.h>


EFI_GUID  gBydPeiOemBoardPpiGuid = BYD_PEI_OEMBOARD_PPI_GUID;

UINT16
BydPeiGetBiosRevision (
  IN  CONST BYD_PEI_OEMBOARD_PPI  *This
  );

EFI_STATUS
EFIAPI
CreateOemDebugHob(IN CONST EFI_PEI_SERVICES     **PeiServices,CHAR8 *Buffer,UINT16 Length);  

// PPI Definition(s)
BYD_PEI_OEMBOARD_PPI gBydOemBoardPpi = {
    BydPeiGetBiosRevision,
    CreateOemDebugHob,
};

// Function Definition(s)

// PPI that are installed
static EFI_PEI_PPI_DESCRIPTOR gBydOemBoardPpiList[] =  
{
    {
        (EFI_PEI_PPI_DESCRIPTOR_PPI | EFI_PEI_PPI_DESCRIPTOR_TERMINATE_LIST),
        &gBydPeiOemBoardPpiGuid,
        &gBydOemBoardPpi
    }
};


UINT16
BydPeiGetBiosRevision (
  IN  CONST BYD_PEI_OEMBOARD_PPI  *This
  )
{
    return (CRB_PROJECT_MAJOR_VERSION << 8) | CRB_PROJECT_MINOR_VERSION;
}


EFI_STATUS
EFIAPI
CreateOemDebugHob(IN CONST EFI_PEI_SERVICES     **PeiServices,CHAR8 *Buffer,UINT16 Length)
{
	OEM_BOARD_DEBUG_BOB *Hob;
	EFI_GUID			OEMBoardDebugHobGuid = BYD_OEM_BOARD_DEBUG_HOB_GUID;
	UINT16				i;

	(*PeiServices)->CreateHob(
							PeiServices,
							EFI_HOB_TYPE_GUID_EXTENSION,
							Length + sizeof(EFI_HOB_GUID_TYPE),
							&Hob
    						);
    Hob->Header.Name = OEMBoardDebugHobGuid;

	for(i=0;i<Length;i++)
	{
		Hob->Buffer[i] = Buffer[i];
	}
    
    return EFI_SUCCESS;
}



EFI_STATUS EFIAPI BydPeiInit (
    IN       EFI_PEI_FILE_HANDLE   FileHandle,
    IN CONST EFI_PEI_SERVICES     **PeiServices )
{
    EFI_STATUS  Status = EFI_SUCCESS;
      
    Status = (*PeiServices)->InstallPpi(PeiServices, &gBydOemBoardPpiList[0]);
    ASSERT_PEI_ERROR (PeiServices, Status); 

    return Status;
}

