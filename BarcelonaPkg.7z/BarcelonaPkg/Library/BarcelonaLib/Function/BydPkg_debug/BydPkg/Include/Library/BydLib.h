
#ifndef __BYD_LIB__H__
#define __BYD_LIB__H__
#ifdef __cplusplus
extern "C" {
#endif

extern EFI_STATUS 
EFIAPI
DxeCreateOemDebugBuffer(IN CHAR8 *Str);

extern EFI_STATUS
EFIAPI
PeiCreateOemDebugHob(IN CONST EFI_PEI_SERVICES       **PeiServices,CHAR8 *Buffer);

extern EFI_STATUS
EFIAPI
AddString(CHAR8 *Des,CHAR8 *Source);

/****** DO NOT WRITE BELOW THIS LINE *******/
#ifdef __cplusplus
}
#endif
#endif

