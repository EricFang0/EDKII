//*************************************************************************
//*************************************************************************
//**                                                                     **
//**        (C)Copyright 1985-2013, American Megatrends, Inc.            **
//**                                                                     **
//**                       All Rights Reserved.                          **
//**                                                                     **
//**      5555 Oakbrook Parkway, Suite 200, Norcross, GA 30093           **
//**                                                                     **
//**                       Phone: (770)-246-8600                         **
//**                                                                     **
//*************************************************************************
//*************************************************************************
//
// $Header: $
//
// $Revision: $
//
// $Date: $
//
//*****************************************************************************
// Revision History
// ----------------
// $Log: $
// 
//*************************************************************************
/** @file CrbInfo.h
    This header file contains the CrbInfo.h definition.

**/
//*************************************************************************

#ifndef _AMI_PROTOCOL_BYDDXE_H_
#define _AMI_PROTOCOL_BYDDXE_H_

typedef struct
{
	UINT16 Year;
	UINT8 Month;
	UINT8 Day;
	UINT8 Hour;
	UINT8 Min;
	UINT8 Sec;
}BIOS_BUILD_TIME;

typedef struct 
{
	UINT8  Major_Version;
	UINT8  Minor_Version;
}BIOS_VERSION;

typedef	struct
{
	BIOS_VERSION 	BIOSVersion;
	BIOS_BUILD_TIME BIOSBuildTime;
}SYSTEM_BIOS_INFO;

typedef struct
{
	UINT16	TotalLength;		//Total debug memory length
	UINT16  DebugNumbers;		//Current Number of Debugmem
	UINT32  FreeMemStartAddress;// Memory Address of Free memory
	SYSTEM_BIOS_INFO BIOSInfo;
}DEBUG_MEM_HEADER;

typedef struct
{
	UINT16 NumberOfDebug;		//Debug NO.
	UINT16 DebugLength;			//Debug length
	UINT32 Reserved;
}DEBUG_MEM_BUFFER_HEADER;

typedef struct 
{
	DEBUG_MEM_BUFFER_HEADER DebugMemBufferHeader;
	CHAR8 *Buffer;				//Debug info
}DEBUG_MEM_BUFFER;

typedef struct
{
	DEBUG_MEM_HEADER DebugMemHeader;
	DEBUG_MEM_BUFFER *DebugMemBuffer;
}OEM_DEBUG_MEMORY;


typedef EFI_STATUS
(EFIAPI *CREATE_NEW_DEBUG_MEM)
(IN UINT16 Length,IN CHAR8 *Str);

typedef EFI_STATUS 
(EFIAPI *UINT32_TO_CHAR8)
(IN UINT32 Hex,OUT CHAR8 *String, OUT UINT8 *Length,IN UINT8 Format);

typedef EFI_STATUS
(EFIAPI *ADD_STRING)
(CHAR8 *Des,CHAR8 *Source);

typedef struct
{
	CREATE_NEW_DEBUG_MEM Create_New_Debug_Mem;
	UINT32_TO_CHAR8  	 Uint32_To_Char8;
	ADD_STRING		 	 Add_String;	
}BYD_DXE_PROTOCOL;


#define BYD_DXE_PROTOCOL_GUID \
        { 0xEC87D643, 0xEBA4, 0x4BB5, 0xA1, 0xE5, 0x3F, 0x3E, 0x36, 0xB2, 0x0D, 0xA9 }


extern EFI_GUID gBydDxeProtocolGuid; 

#define OEM_VARIABLE_GUID \
  { 0x9987d643, 0xeba4, 0x4bb5, 0xa1, 0xe5, 0x3f, 0x3e, 0x36, 0xb2, 0xd, 0x99}

extern EFI_GUID OEMVariableGuid;

typedef struct
{
	UINT16 ResetCount;		//
	UINT16 CurrentResetCount;
	UINT8  ResetFlag;			//Bit0: 0:Reset Finish,1:Reseting; [1:2]: 0:Warm,1:Cold,2:gReset;  Bit3: 
	UINT16 Year;
	UINT8  Month;
	UINT8  Day;
	UINT32 OemDebugBufferAddr;
	UINT32 OemDebugBufferSize;
}OemVariableDef;

extern EFI_STATUS EFIAPI
CreateNewDebugMem(IN UINT16 Length,IN CHAR8 *Str);

extern EFI_STATUS EFIAPI 
Uint32ToChar8(IN UINT32 Hex,OUT CHAR8 *String, OUT UINT8 *Length,IN UINT8 Format);

extern EFI_STATUS
EFIAPI
AddString(CHAR8 *Des,CHAR8 *Source);

#endif /* _AMI_PROTOCOL_CRBINFO_H_ */

//*************************************************************************
//*************************************************************************
//**                                                                     **
//**        (C)Copyright 1985-2013, American Megatrends, Inc.            **
//**                                                                     **
//**                       All Rights Reserved.                          **
//**                                                                     **
//**      5555 Oakbrook Parkway, Suite 200, Norcross, GA 30093           **
//**                                                                     **
//**                       Phone: (770)-246-8600                         **
//**                                                                     **
//*************************************************************************
//*************************************************************************
