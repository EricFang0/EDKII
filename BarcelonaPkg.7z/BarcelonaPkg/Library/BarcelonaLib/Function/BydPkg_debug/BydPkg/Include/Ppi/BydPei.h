//*************************************************************************
//*************************************************************************
//**                                                                     **
//**        (C)Copyright 1985-2013, American Megatrends, Inc.            **
//**                                                                     **
//**                       All Rights Reserved.                          **
//**                                                                     **
//**      5555 Oakbrook Parkway, Suite 200, Norcross, GA 30093           **
//**                                                                     **
//**                       Phone: (770)-246-8600                         **
//**                                                                     **
//*************************************************************************
//*************************************************************************
//
// $Header: $
//
// $Revision: $
//
// $Date: $
//
//*****************************************************************************
// Revision History
// ----------------
// $Log: $
// 
//*************************************************************************
/** @file CrbInfo.h
    This header file contains the CrbInfo.h definition.

**/
//*************************************************************************

#ifndef _BYD_PPI_OEMBOARD_H_
#define _BYD_PPI_OEMBOARD_H_

#define EFI_HOB_TYPE_BYD_OEM_BOARD_DEBUG      0xFFF0

#define BYD_OEM_BOARD_DEBUG_HOB_GUID \
  { 0x8bfe1742, 0xa5b2, 0x431c, 0x8b, 0x67, 0x3, 0xea, 0x20, 0x3c, 0x96, 0xf2}

#define BYD_PEI_OEMBOARD_PPI_GUID \
  { 0x5df3470b, 0x451e, 0x424a, {0x9b, 0xf9, 0x61, 0xc2, 0x91, 0x89, 0x1d, 0x3b} }  

typedef struct _BYD_PEI_OEMBOARD_PPI  BYD_PEI_OEMBOARD_PPI;

#pragma pack(1)

typedef struct _OEM_BOARD_DEBUG_BOB{
	EFI_HOB_GUID_TYPE	Header;
	CHAR8				Buffer[20];
}OEM_BOARD_DEBUG_BOB;


typedef
UINT16
(EFIAPI *BYD_PEI_OEMBOARD_GET_BIOS_REVISION)(
  IN  CONST BYD_PEI_OEMBOARD_PPI  *This
);

typedef
EFI_STATUS
(EFIAPI *CREATE_OEM_DEBUG_HOB)(
	IN CONST EFI_PEI_SERVICES     **PeiServices,CHAR8 *Buffer,UINT16 Length
);

struct _BYD_PEI_OEMBOARD_PPI{
  BYD_PEI_OEMBOARD_GET_BIOS_REVISION         GetBiosRevision;
  CREATE_OEM_DEBUG_HOB						 Create_Oem_Debug_Hob;
};


extern EFI_GUID  gBydPeiOemBoardPpiGuid;

#pragma pack()

#endif /* _AMI_PPI_CRBINFO_H_ */

//*************************************************************************
//*************************************************************************
//**                                                                     **
//**        (C)Copyright 1985-2013, American Megatrends, Inc.            **
//**                                                                     **
//**                       All Rights Reserved.                          **
//**                                                                     **
//**      5555 Oakbrook Parkway, Suite 200, Norcross, GA 30093           **
//**                                                                     **
//**                       Phone: (770)-246-8600                         **
//**                                                                     **
//*************************************************************************
//*************************************************************************
