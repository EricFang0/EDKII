#include <Efi.h>
#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Token.h>
#include <AmiDxeLib.h>
#include <AmiCspLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/UefiLib.h>
#include <Library/PcdLib.h>
#include <Protocol/BydDxe.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Protocol/AmiSmbios.h>
#include <Protocol/SmbiosUpdateDataProtocol.h>
#include <Build/TimeStamp.h>
#include <Library/HobLib.h>
#include <Ppi/BydPei.h>
#include <Library/BydLib.h>

EFI_STATUS
EFIAPI
DxeCreateOemDebugBuffer(IN CHAR8 *Str)
{
	EFI_STATUS 				Status = EFI_SUCCESS;
	BYD_DXE_PROTOCOL 	    *BydDxeProcotol;
	UINT16					StrSize = (UINT16)Strlen(Str);
	EFI_GUID                BydDxeProtocolGuid = BYD_DXE_PROTOCOL_GUID;
	
	Status = pBS->LocateProtocol(
						&BydDxeProtocolGuid,
						NULL,
						&BydDxeProcotol
						);
	
	if(EFI_ERROR(Status))
	{
	    TRACE((-1, "Eric DXE Test Error\n"));
		return Status;
	}

	Status = BydDxeProcotol->Create_New_Debug_Mem(StrSize,Str);
	
	return Status;
}

EFI_STATUS
EFIAPI
AddString(CHAR8 *Des,CHAR8 *Source)
{
	//gBS->CopyMem(Des + strlen(Des),Source,strlen(Source));
	UINT16 DesLength = strlen(Des);
	UINT16 SourceLength = strlen(Source);
	
	StrCpy8(Des+DesLength,Source);
	
	return EFI_SUCCESS;
}

