#include <Efi.h>
#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Token.h>
#include <AmiDxeLib.h>
#include <AmiCspLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/UefiLib.h>
#include <Library/PcdLib.h>
#include <Protocol/BydDxe.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Protocol/AmiSmbios.h>
#include <Protocol/SmbiosUpdateDataProtocol.h>
#include <Build/TimeStamp.h>
#include <Library/HobLib.h>
#include <Ppi/BydPei.h>
#include <Library/BydLib.h>

EFI_STATUS
EFIAPI
PeiCreateOemDebugHob(IN CONST EFI_PEI_SERVICES       **PeiServices,CHAR8 *Buffer)
{
	OEM_BOARD_DEBUG_BOB *Hob;
	EFI_GUID			OEMBoardDebugHobGuid = BYD_OEM_BOARD_DEBUG_HOB_GUID;
	UINT16				i;
	UINT16              Length = strlen(Buffer);

	(*PeiServices)->CreateHob(
							PeiServices,
							EFI_HOB_TYPE_GUID_EXTENSION,
							Length + sizeof(EFI_HOB_GUID_TYPE),
							&Hob
    						);
    Hob->Header.Name = OEMBoardDebugHobGuid;

	for(i=0;i<Length;i++)
	{
		Hob->Buffer[i] = Buffer[i];
	}
    
    return EFI_SUCCESS;
}


