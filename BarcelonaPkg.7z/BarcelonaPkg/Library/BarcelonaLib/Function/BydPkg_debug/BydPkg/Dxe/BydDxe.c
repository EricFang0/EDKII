//----------------------------------------------------------------------------
// Include(s)
//----------------------------------------------------------------------------
#include <Efi.h>
#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Token.h>
#include <AmiDxeLib.h>
#include <AmiCspLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/UefiLib.h>
#include <Library/PcdLib.h>
#include <Protocol/BydDxe.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Protocol/AmiSmbios.h>
#include <Protocol/SmbiosUpdateDataProtocol.h>
#include <Build/TimeStamp.h>
#include <Library/HobLib.h>
#include <Ppi/BydPei.h>
#include <Library/BydLib.h>
//----------------------------------------------------------------------------
// Constant, Macro and Type Definition(s)
//----------------------------------------------------------------------------
// Constant Definition(s)

// Macro Definition(s)

// Type Definition(s)

// Function Prototype(s)

OEM_DEBUG_MEMORY *OemDebugMemory;
EFI_EVENT		 OemVarNotifyEvent;
VOID 			 *OemVarNotifyRegistration;

EFI_GUID gBydDxeProtocolGuid = BYD_DXE_PROTOCOL_GUID; 


BYD_DXE_PROTOCOL BydDxeProtocol=
{
	CreateNewDebugMem,
	Uint32ToChar8,
	AddString,
};

static EFI_GUID gEfiBdsArchProtocolGuid = { 0x665E3FF6, 0x46CC, 0x11D4, { 0x9A, 0x38, 0x00, 0x90, 0x27, 0x3F, 0xC1, 0x4D }};

EFI_GUID OEMVariableGuid = OEM_VARIABLE_GUID;


VOID
EFIAPI
OemVariableNotificationFunction (
    EFI_EVENT   Event,
    VOID *RegContext
)
{
	EFI_STATUS 			Status;
	UINTN				BufferSize = sizeof(OemVariableDef);
	CHAR16				*VariableName = L"OemVariable";
	OemVariableDef		OemVariable;
	EFI_TIME			Time;

	TRACE((-1, "New Oem variable!\n"));
	
	OemVariable.OemDebugBufferAddr = PcdGet32(OemDebugMemoryBaseAddress);
	OemVariable.OemDebugBufferSize = PcdGet32(OemDebugMemorySize);
	
	gRT->GetTime(&Time,NULL);
	
	OemVariable.Year = Time.Year;
	OemVariable.Month = Time.Month;
	OemVariable.Day = Time.Day;

	OemVariable.ResetFlag = 0;
	OemVariable.CurrentResetCount = 0;
	OemVariable.ResetCount = 0;

	Status = pRS->SetVariable(
							VariableName,
							&OEMVariableGuid,							
							EFI_VARIABLE_BOOTSERVICE_ACCESS|EFI_VARIABLE_RUNTIME_ACCESS|EFI_VARIABLE_NON_VOLATILE,
							BufferSize,
							&OemVariable
							);		
	
	if(Status == EFI_SUCCESS)
	{
	    pBS->CloseEvent(Event);
	}
	
	return;
}


VOID RegisterOemVarNotification()
{
	TRACE((-1, "Register Oem variable notify !\n"));
    EfiCreateProtocolNotifyEvent(
								&gSmbiosUpdateDataProtocolGuid,
								TPL_CALLBACK,
								OemVariableNotificationFunction,
								NULL,
								&OemVarNotifyRegistration
    							);	
}

EFI_STATUS
EFIAPI
GetDebugHobs()
{
	EFI_HOB_GENERIC_HEADER  *Hob;
	OEM_BOARD_DEBUG_BOB 	*HobData;
	UINTN					HobDataSize;
	EFI_GUID				PeiDebugHobGuid = BYD_OEM_BOARD_DEBUG_HOB_GUID;
	CHAR8					*Buffer = NULL;

	Hob = GetHobList();
	while((Hob = GetNextGuidHob(&PeiDebugHobGuid, Hob))!=NULL)
	{
		HobData = GET_GUID_HOB_DATA(Hob);
		HobDataSize = GET_GUID_HOB_DATA_SIZE(Hob);

		pBS->CopyMem(Buffer,HobData,HobDataSize);

		CreateNewDebugMem((UINT16)HobDataSize,Buffer);

		Hob = GET_NEXT_HOB(Hob);
	}

	return EFI_SUCCESS;
}

/**
    This function is the entry point for this DXE. This function
    initializes the DebugMemory

    @param Length, the legth of the memory for debug
    @param SystemTable Pointer to the system table

    @retval Return Status based on errors that occurred while waiting for
        time to expire.

**/
EFI_STATUS
OemDebugMemoryInit(UINTN Length)
{
	EFI_STATUS 		Status = EFI_SUCCESS;
	
	Status = pBS->AllocatePool(EfiRuntimeServicesData,Length,&OemDebugMemory);
	if(EFI_ERROR(Status))
	{
	    TRACE((-1, "Allocate memory for Debug fail !\n"));
		return Status;
	}
	pBS->SetMem(OemDebugMemory,Length,0);

	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSVersion.Major_Version = CRB_PROJECT_MAJOR_VERSION;
	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSVersion.Minor_Version = CRB_PROJECT_MINOR_VERSION;
	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSBuildTime.Year = THIS_YEAR;
	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSBuildTime.Month = THIS_MONTH;
	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSBuildTime.Day = THIS_DAY;
	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSBuildTime.Hour = THIS_HOUR;
	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSBuildTime.Min = THIS_MINUTE;
	OemDebugMemory->DebugMemHeader.BIOSInfo.BIOSBuildTime.Sec = THIS_SECOND;

	OemDebugMemory->DebugMemHeader.DebugNumbers = 0;
	OemDebugMemory->DebugMemHeader.TotalLength = (UINT16)Length;
	OemDebugMemory->DebugMemHeader.FreeMemStartAddress = (UINT32)OemDebugMemory + sizeof(DEBUG_MEM_HEADER);
	
	PcdSet32(OemDebugMemoryBaseAddress, (UINT32)OemDebugMemory);
	PcdSet32(OemDebugMemorySize, (UINT32)Length);
	
	TRACE((-1, "OemDebugMemoryBaseAddress = %x \n",(UINT32)OemDebugMemory));
	
	return Status;
}

EFI_STATUS
EFIAPI
CreateNewDebugMem(IN UINT16 Length,IN CHAR8 *Str)
{
	EFI_STATUS 		 Status = EFI_SUCCESS;
	DEBUG_MEM_BUFFER *DebugMemBuffer;
	UINT8			 BufferHeaderSize = sizeof(DEBUG_MEM_BUFFER_HEADER);
	UINT16			 BufferSize = Length + BufferHeaderSize;

	Status = pBS->AllocatePool(EfiBootServicesData,BufferSize,&DebugMemBuffer);
	pBS->SetMem(DebugMemBuffer,(UINTN)BufferSize,0);

	OemDebugMemory->DebugMemHeader.DebugNumbers +=1 ;
	DebugMemBuffer->DebugMemBufferHeader.DebugLength = Length;
	DebugMemBuffer->DebugMemBufferHeader.NumberOfDebug = OemDebugMemory->DebugMemHeader.DebugNumbers;
	
	TRACE((-1, "BydDxeInit Str= %s\n",Str));
	pBS->CopyMem(&(DebugMemBuffer->Buffer),Str,(UINTN)Length);

	pBS->CopyMem((UINT32*)OemDebugMemory->DebugMemHeader.FreeMemStartAddress, DebugMemBuffer, (UINTN)BufferSize);
	OemDebugMemory->DebugMemHeader.FreeMemStartAddress += BufferSize;

	Status = pBS->FreePool(DebugMemBuffer);
	return Status;
}


EFI_STATUS 
EFIAPI
Uint32ToChar8(IN UINT32 Hex,OUT CHAR8 *String, OUT UINT8 *Length,IN UINT8 Format)
{
	UINT8 num=0;
	CHAR8 Str[15];
	CHAR8 TempStr[15];
	UINT8 StrOffset = 0;
	UINT8 Index;

	while(Hex/Format)
	{
		StrOffset = 0x37;		//-10 + 0x41
		if((Hex%Format)<10)
		{
			StrOffset = 0x30;
		}
		Str[num] = (Hex%Format + StrOffset);
	
		num++;
		Hex = Hex/Format;		
	}

	StrOffset = 0x37;
	if(Hex < 10)
	{
		StrOffset = 0x30;
	}
	Str[num] = (UINT8)(Hex + StrOffset);
	num++;

	for(Index=0; Index<num; Index++)
	{
		TempStr[Index] = Str[num-Index-1];
	}
	
	gBS->CopyMem(String,TempStr,num);

	*Length = num;
	
	return EFI_SUCCESS;	
}

EFI_STATUS
EFIAPI
AddString(CHAR8 *Des,CHAR8 *Source)
{
	gBS->CopyMem(Des + strlen(Des),Source,strlen(Source));
	return EFI_SUCCESS;
}

CHAR16 *
OemAscii2Unicode (
  OUT CHAR16         *UnicodeStr,
  IN  CHAR8          *AsciiStr
  )
/*++

Routine Description:
  Converts ASCII characters to Unicode.

Arguments:
  UnicodeStr - the Unicode string to be written to. The buffer must be large enough.
  AsciiStr   - The ASCII string to be converted.

Returns:
  The address to the Unicode string - same as UnicodeStr.

--*/
{
  CHAR16  *Str;

  Str = UnicodeStr;

  while (TRUE) {

    *(UnicodeStr++) = (CHAR16) *AsciiStr;

    if (*(AsciiStr++) == '\0') {
      return Str;
    }
  }
}

/**
    This function is the entry point for this BYD. This function
    initializes the BYD

    @param ImageHandle Image handle
    @param SystemTable Pointer to the system table

    @retval Return Status based on errors that occurred while waiting for
        time to expire.

**/
EFI_STATUS EFIAPI BydDxeInit (
    IN EFI_HANDLE       ImageHandle,
    IN EFI_SYSTEM_TABLE *SystemTable )
{
    EFI_STATUS          Status = EFI_SUCCESS;

	InitAmiLib(ImageHandle, SystemTable);
	
	TRACE((-1, "BydDxeInit \n"));
	OemDebugMemoryInit(OEMDebugMemoryLength);
	GetDebugHobs();

	Status = pBS->InstallMultipleProtocolInterfaces(
													&ImageHandle,
													&gBydDxeProtocolGuid,&BydDxeProtocol,
													NULL
													);    
	RegisterOemVarNotification();
    return Status;
}

